#' Forward dosimetry
#'
#' Runs a physiologically based kinetic (PBK) model for one or both PFAS
#' chemicals (PFOA, PFOS) and performs Bayesian model averaging (BMA) over
#' predicted serum and liver concentrations. The function validates inputs,
#' constructs a model specification internally, simulates the exposure scenario,
#' and returns both BMA outputs and individual model trajectories.
#'
#' @param chemical Character string; one of \code{"PFOA"}, \code{"PFOS"}, or
#'   \code{"BOTH"} (case-insensitive).
#' @param ingestion Numeric, daily intake in ng/kg/day.
#' @param BW Numeric, body weight in kg.
#' @param duration Numeric, total simulation time in the units specified by
#'   \code{time_scale}. Must satisfy \eqn{\ge} 1.
#' @param time_scale Character string, one of \code{"minutes"}, \code{"hours"},
#'   \code{"days"}, \code{"weeks"}, \code{"months"}, or \code{"years"}. The value
#'   of \code{ingestion} is always interpreted as ng/kg/day and automatically
#'   converted to the internal units required by the PBK models.
#'   @param free Logical; if \code{TRUE}, free concentrations will be estimated. Default value is \code{FALSE}
#' @param Nsamples Integer; number of posterior draws used in the BMA procedure
#'   at each simulated time point.
#' @param stat_sum Logical; controls the BMA output format.  
#'   If \code{TRUE} (default), summary statistics are returned
#'   (mean, sd, and selected quantiles).  
#'   If \code{FALSE}, all BMA predictive draws are returned.
#' @param seed Integer; random seed used when sampling from the posterior and,
#'   when \code{isParallel = TRUE}, to initialise parallel random number streams.
#' @param solver Character string; ODE solver name passed internally to the
#'   differential equation integrator (e.g., \code{"lsodes"}).
#' @param rtol Relative tolerance for the numerical ODE solver.
#' @param atol Absolute tolerance for the numerical ODE solver.
#'
#' @details
#' The function performs the following high-level steps:
#'
#' \enumerate{
#'   \item Validates input parameters (\code{ingestion > 0}, \code{BW > 0},
#'         \code{duration ≥ 1}).
#'   \item Converts the ingestion rate into the units implied by
#'         \code{time_scale}.
#'   \item Generates a time grid from 0 to \code{duration}.
#'   \item Runs the PBK model for the chosen chemical(s) under continuous
#'         ingestion.
#'   \item Applies Bayesian model averaging to serum and liver predictions using
#'         posterior weights and error variances.
#' }
#'
#' When \code{stat_sum = TRUE}, the BMA results contain summary statistics at
#' each time point:
#'
#' \itemize{
#'   \item \code{mean}
#'   \item \code{sd}
#'   \item \code{p1}, \code{p5}, \code{p25}, \code{p50},
#'         \code{p75}, \code{p95}, \code{p99}
#' }
#'
#' When \code{stat_sum = FALSE}, the function instead returns the full set of
#' \code{Nsamples} posterior predictive draws for each time point.
#'
#' @return A named list with two elements:
#' \describe{
#'   \item{\code{PFOA}}{
#'     A list containing:
#'     \itemize{
#'       \item \code{bma}: Bayesian model averaging output for serum and liver
#'         (summary statistics or full draws, depending on \code{stat_sum}).
#'       \item \code{single_models}: predicted serum and liver trajectories for
#'         each individual PBK model included in the averaging.
#'     }
#'     Returns \code{NULL} if PFOA was not requested.
#'   }
#'
#'   \item{\code{PFOS}}{
#'     Same structure as \code{PFOA}. Returns \code{NULL} if PFOS was not
#'     requested.
#'   }
#' }
#'
#' @examples
#' \dontrun{
#' # Single chemical (PFOA), 3-year simulation
#' out <- forward_dosimetry(
#'   chemical = "pfoa",
#'   ingestion = 5,
#'   BW = 70,
#'   duration = 3,
#'   Nsamples = 1000
#' )
#'
#' # Access BMA serum results
#' head(out$PFOA$bma$serum_df)
#'
#' # Both chemicals with summary statistics
#' out2 <- forward_dosimetry("BOTH", ingestion = 3, BW = 75, duration = 5)
#' }
#'
#' @export

forward_dosimetry <- function(chemical, ingestion, BW, duration, time_scale = "years",free = FALSE,
                              Nsamples = 4000, stat_sum = TRUE,  seed = 123, 
                              solver = "lsodes", rtol = 1e-4, atol = 1e-4, free_liver_from_serum = TRUE){ 
  vars <- list(ingestion = ingestion, BW = BW, duration = duration)
  mins <- c(ingestion = 0, BW = 0, duration = 1)
  
  for (name in names(vars)) {
    x <- vars[[name]]
    if (!is.numeric(x)) stop(name, " should be numeric")
    if (x < mins[name]) {
      stop(name, " should be greater than ", mins[name])
    }
  }
  
  exposure_time <- sort(unique(c(seq(0, floor(duration), 1), duration)))  #in same time units as time scale
  
 if (time_scale == "minutes"){
   ingestion_input <- (1/24/60)*ingestion*BW/1000 #ug/minute
  }else if (time_scale == "hours"){
    ingestion_input <- (1/24)*ingestion*BW/1000 #ug/hour
  }else if (time_scale == "days"){
    ingestion_input <- ingestion*BW/1000 #ug/day
  }else if (time_scale == "weeks"){
    ingestion_input <- 7*ingestion*BW/1000 #ug/week
  }else if (time_scale == "months"){
    ingestion_input <- 30*ingestion*BW/1000 #ug/month
  }else if (time_scale == "years"){
    ingestion_input <- 365*ingestion*BW/1000 #ug/year
  }
  
  user_input <- list(
    'BW' = BW,
    "exposure_time" = exposure_time,
    'chemical' = NA,
    "ingestion" = ingestion_input,
    "ingestion_time" = 0,
    "admin_dose" = 0,
    "admin_time" = 0,
    "admin_type" = "oral",
    "study" = NA,
    "model" = NA,
    "exp_type" = "continuous",
    "time_scale" = time_scale,
    "free" = free,
    "free_liver_from_serum" = free_liver_from_serum
  )
  
  # Check here how you can take a case insensitive input
  if(toupper(chemical) == "PFOA"){
    user_input$chemical <- "PFOA"
    results_PFOA <- .forward_dosimetry_single_chem(user_input = user_input, Nsamples = Nsamples,
                                                   stat_sum = stat_sum, seed = seed,
                                                  solver = solver, rtol = rtol, atol = atol)
    results_PFOS <- NULL
  }else if (toupper(chemical) == "PFOS"){
    user_input$chemical <- "PFOS"
    results_PFOS <- .forward_dosimetry_single_chem(user_input = user_input,  Nsamples = Nsamples, 
                                                  stat_sum = stat_sum, seed = seed,
                                                  solver = solver, rtol = rtol, atol = atol)
    results_PFOA <- NULL
  }else if (toupper(chemical) == "BOTH"){
    user_input$chemical <- "PFOA"
    results_PFOA <- .forward_dosimetry_single_chem(user_input = user_input, Nsamples = Nsamples,
                                                  stat_sum = stat_sum, seed = seed,
                                                  solver = solver, rtol = rtol, atol = atol)
    user_input$chemical <- "PFOS"
    results_PFOS <- .forward_dosimetry_single_chem(user_input = user_input, Nsamples = Nsamples,
                                                  stat_sum = stat_sum,  seed = seed,
                                                  solver = solver, rtol = rtol, atol = atol)
  }else {
    stop("chemical must be one PFOA, PFOS or BOTH")
    }
    
  return(list("PFOA" = results_PFOA, "PFOS" = results_PFOS))
}


#' Reverse dosimetry
#'
#' Estimates continuous exposure levels that reproduce user-specified
#' points of departure (PODs) in serum or liver at selected time points,
#' using a physiologically based kinetic (PBK) model with Bayesian
#' model averaging (BMA).
#'
#' @param chemical Character scalar. Which chemical to run:
#'   \code{"PFOA"}, \code{"PFOS"}, or \code{"BOTH"}. Matching is case-insensitive.
#' @param BW Numeric scalar. Body weight (e.g. in kg).
#' @param duration Numeric scalar. Total simulation time in the units specified
#'   by \code{time_scale}. Must satisfy \eqn{\ge 1}. The exposure time grid is
#'   internally generated as \code{seq(0, duration, 1)}.
#' @param time_scale Character string, one of \code{"minutes"}, \code{"hours"},
#'   \code{"days"}, \code{"weeks"}, \code{"months"} or \code{"years"}. Times in
#'   \code{bmd_df$time} are interpreted in these units.
#'   @param free Logical; if \code{TRUE}, free concentrations will be estimated. Default value is \code{FALSE}
#' @param bmd_df A \code{data.frame} with exactly four columns named:
#'   \itemize{
#'     \item \code{POD} — numeric target internal concentration (point of departure).
#'     \item \code{compartment} — character; one of \code{"serum"} or \code{"liver"}
#'           (case-insensitive).
#'     \item \code{key_event} — character label for the biological key event
#'           (free text, used for tracing).
#'     \item \code{time} — numeric time at which the POD should be met, in
#'           the units defined by \code{time_scale}.
#'   }
#'   Column names must match these exactly (order may differ).
#' @param isStochastic Logical. If \code{FALSE} (default), a single
#'   BMA-based exposure estimate is returned for each row of \code{bmd_df}
#'   (deterministic mode, using mean posterior model weights and no
#'   stochastic error).  
#'   If \code{TRUE}, reverse dosimetry is performed under a stochastic BMA
#'   scheme that samples from the posterior model weights and a log-normal
#'   error model. In this mode, \code{isParallel} must be \code{TRUE};
#'   otherwise an error is raised.
#' @param isParallel Logical. If \code{TRUE}, Monte Carlo computations used by
#'   the stochastic reverse-dosimetry procedure are run in parallel (where
#'   implemented). For \code{isStochastic = TRUE}, \code{isParallel} must be
#'   \code{TRUE}. In deterministic mode (\code{isStochastic = FALSE}), this
#'   flag is ignored.
#' @param Nsamples Integer. Number of Monte Carlo / posterior samples used in
#'   the stochastic mode (\code{isStochastic = TRUE}). Ignored in deterministic
#'   mode.
#' @param n_cores Integer or \code{NULL}. Number of CPU cores to use when
#'   \code{isParallel = TRUE}. If \code{NULL}, a sensible default is chosen
#'   internally (typically based on \code{parallel::detectCores()}).
#' @param stat_sum Logical; controls the stochastic output format when
#'   \code{isStochastic = TRUE}.  
#'   If \code{FALSE}, the function returns all \code{Nsamples} reverse-dosimetry
#'   draws (one value per Monte Carlo sample) in the \code{exposure} and
#'   \code{rel_error} fields.  
#'   If \code{TRUE}, the function returns summary statistics of these draws
#'   (mean, sd, and selected quantiles) in \code{exposure} and
#'   \code{rel_error}. In deterministic mode (\code{isStochastic = FALSE}),
#'   \code{stat_sum} is ignored and single values are returned.
#' @param seed Integer. Random seed used when drawing Monte Carlo samples in
#'   stochastic mode. When \code{isParallel = TRUE}, this is also used to
#'   initialise the parallel random number streams.
#' @param optim_tol Numeric scalar. Tolerance passed to the numerical optimiser
#'   for the reverse-dosimetry objective (e.g. \code{1e-3}).
#' @param solver Character scalar. ODE solver to use internally
#'   (e.g. \code{"lsodes"}).
#' @param rtol,atol Numeric scalars. Relative and absolute tolerances for the
#'   numerical ODE solver.
#'
#' @details
#' For each requested chemical, the function:
#' \enumerate{
#'   \item Builds an internal \code{user_input} structure describing continuous
#'         oral exposure (no bolus dosing) over the specified \code{duration}.
#'   \item Simulates the PBK system until the requested times.
#'   \item For each row of \code{bmd_df}, searches for the continuous intake
#'         that yields the specified \code{POD} in the requested
#'         \code{compartment} at the given \code{time}.
#' }
#'
#' In deterministic mode (\code{isStochastic = FALSE}), a single exposure
#' estimate and its associated relative error are produced for each
#' POD/compartment/time combination. These are returned as scalar values in
#' the \code{exposure} and \code{rel_error} fields.
#'
#' In stochastic mode (\code{isStochastic = TRUE}), the reverse-dosimetry step
#' is repeated \code{Nsamples} times using draws from the posterior model
#' weights and the log-normal error distribution, yielding a distribution of
#' exposure estimates per POD/compartment/time combination:
#' \itemize{
#'   \item If \code{stat_sum = FALSE}, \code{exposure} and \code{rel_error}
#'         are numeric vectors containing all \code{Nsamples} draws.
#'   \item If \code{stat_sum = TRUE}, \code{exposure} and \code{rel_error}
#'         are named numeric vectors containing summary statistics (mean, sd,
#'         and quantiles such as p1, p5, p25, p50, p75, p95, p99), analogous
#'         to the forward-dosimetry summaries.
#' }
#'
#' Basic input checks include:
#' \itemize{
#'   \item \code{BW} must be numeric and \eqn{> 0}.
#'   \item \code{duration} must be numeric and \eqn{\ge 1}.
#'   \item \code{bmd_df} must have exactly the four required columns.
#'   \item \code{compartment} must be either \code{"serum"} or \code{"liver"}
#'         (case-insensitive).
#' }
#'
#' @return A named \code{list} with elements \code{PFOA} and \code{PFOS}.
#' Each element is either:
#' \itemize{
#'   \item \code{NULL}, if the corresponding chemical was not requested, or
#'   \item an object containing one reverse-dosimetry result per row of
#'         \code{bmd_df}, including at least:
#'         \itemize{
#'           \item \code{exposure} — estimated continuous intake(s) that achieve
#'                 the requested POD(s); either a single value (deterministic),
#'                 a vector of draws, or a vector of summary statistics,
#'                 depending on \code{isStochastic} and \code{stat_sum}.
#'           \item \code{rel_error} — relative error(s) between the achieved
#'                 internal concentrations and the target POD(s), in the same
#'                 format as \code{exposure}.
#'           \item \code{POD}, \code{compartment}, \code{key_event}, \code{time}
#'                 — the corresponding input POD definition.
#'         }
#' }
#'
#' @examples
#' \dontrun{
#' bmd_df <- data.frame(
#'   POD = c(5, 10),
#'   compartment = c("serum", "liver"),
#'   key_event = c("KE1", "KE2"),
#'   time = c(1, 2) # in time_scale units, e.g. years
#' )
#'
#' # Deterministic reverse dosimetry for PFOA
#' out_pfoa <- reverse_dosimetry(
#'   chemical = "PFOA",
#'   BW = 70,
#'   duration = 5,
#'   time_scale = "years",
#'   bmd_df = bmd_df,
#'   solver = "lsodes", rtol = 1e-4, atol = 1e-4
#' )
#'
#' # Stochastic reverse dosimetry (full draws, requires isParallel = TRUE)
#' out_pfoa_stoch_draws <- reverse_dosimetry(
#'   chemical = "PFOA",
#'   BW = 70,
#'   duration = 5,
#'   time_scale = "years",
#'   bmd_df = bmd_df,
#'   isStochastic = TRUE,
#'   isParallel = TRUE,
#'   Nsamples = 50,
#'   stat_sum = FALSE
#' )
#'
#' # Stochastic reverse dosimetry (summary statistics)
#' out_pfoa_stoch_sum <- reverse_dosimetry(
#'   chemical = "PFOA",
#'   BW = 70,
#'   duration = 5,
#'   time_scale = "years",
#'   bmd_df = bmd_df,
#'   isStochastic = TRUE,
#'   isParallel = TRUE,
#'   Nsamples = 50,
#'   stat_sum = TRUE
#' )
#'
#' # Both chemicals
#' out_both <- reverse_dosimetry(
#'   chemical = "BOTH",
#'   BW = 70,
#'   duration = 5,
#'   time_scale = "years",
#'   bmd_df = bmd_df
#' )
#' }
#'
#' @export
reverse_dosimetry <- function( chemical, BW, duration, time_scale = "years", bmd_df, free = FALSE,
                               isStochastic = FALSE, isParallel = FALSE, Nsamples = 30, 
                               n_cores = NULL,  stat_sum = FALSE, seed = 123,
                               optim_tol = 1e-3, 
                               solver = "lsodes", rtol = 1e-4, atol = 1e-4, free_liver_from_serum = TRUE){
  vars <- list(BW = BW, duration = duration)
  mins <- c(ingestion = 0, BW = 0, duration = 1)
  
  for (name in names(vars)) {
    x <- vars[[name]]
    if (!is.numeric(x)) stop(name, " should be numeric")
    if (x < mins[name]) {
      stop(name, " should be greater than ", mins[name])
    }
  }

  required_cols <- c("POD", "compartment", "key_event", "time")
  
  if (ncol(bmd_df) != length(required_cols)) {
    stop("bmd_df should have exactly 4 columns")
  }
  
  if (!setequal(colnames(bmd_df), required_cols)) {
    stop("The colnames of bmd_df should be exactly: 'POD', 'compartment', 'key_event', and 'time'")
  }
  
  if (!all(toupper(bmd_df$compartment) %in% c("SERUM", "LIVER"))) {
    stop("The compartment can be either 'liver' or 'serum'.")
  }

  exposure_time <- sort(unique(c(seq(0, floor(duration), 1), duration))) #in same time units as time scale

  user_input <- list(
    'BW' = BW,
    "exposure_time" = exposure_time,
    'chemical' = chemical,
    "ingestion" = 0,
    "ingestion_time" = 0,
    "admin_dose" = 0,
    "admin_time" = 0,
    "admin_type" = "oral",
    "study" = NA,
    "model" = NA,
    "exp_type" = "continuous",
    "time_scale" = time_scale,
    "free" = free,
    "free_liver_from_serum" = free_liver_from_serum
  )
  # Check here how you can take a case insensitive input
  if(toupper(chemical) == "PFOA"){
    user_input$chemical <- "PFOA"
    results_PFOA <- .reverse_dosimetry_single_chem(user_input = user_input, bmd_df,
                                                  isParallel = isParallel, isStochastic = isStochastic,
                                                 Nsamples = Nsamples, n_cores = n_cores,
                                                 stat_sum = stat_sum,seed =seed,
                                                 optim_tol = optim_tol, solver = solver, rtol = rtol, atol = atol)
    results_PFOS <- NULL
  }else if (toupper(chemical) == "PFOS"){
    user_input$chemical <- "PFOS"
    results_PFOS <- .reverse_dosimetry_single_chem(user_input = user_input,  bmd_df,
                                                  isParallel = isParallel, isStochastic = isStochastic,
                                                  Nsamples = Nsamples, n_cores = n_cores,
                                                  stat_sum = stat_sum,seed =seed,
                                                  optim_tol = optim_tol, solver = solver, rtol = rtol, atol = atol)
    results_PFOA <- NULL
  }else if (toupper(chemical) == "BOTH"){
    user_input$chemical <- "PFOA"
    results_PFOA <- .reverse_dosimetry_single_chem(user_input = user_input, bmd_df,
                                                  isParallel = isParallel, isStochastic = isStochastic,
                                                  Nsamples = Nsamples, n_cores = n_cores,
                                                  stat_sum = stat_sum,seed =seed,
                                                  optim_tol = optim_tol, solver = solver, rtol = rtol, atol = atol)
    user_input$chemical <- "PFOS"
    results_PFOS <- .reverse_dosimetry_single_chem(user_input = user_input,  bmd_df,
                                                  isParallel = isParallel, isStochastic = isStochastic,
                                                  Nsamples = Nsamples, n_cores = n_cores,
                                                  stat_sum = stat_sum,seed =seed,
                                                  optim_tol = optim_tol, solver = solver, rtol = rtol, atol = atol)
  }else {
    stop("chemical must be one PFOA, PFOS or BOTH")
  }
  
  return(list("PFOA" = results_PFOA, "PFOS" = results_PFOS))
}
