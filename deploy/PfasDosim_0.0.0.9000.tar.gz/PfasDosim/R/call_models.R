

#' Run chiu PBK model (internal)
#'
#' Builds parameters, initial states, and events for the chiu model
#' and solves the system with `deSolve::ode()`.
#'
#' @param user_input List with fields required by the model (e.g., `exposure_time`, dosing, BW, etc.).
#' @param solver Character or function passed to `deSolve::ode(method=)`. Defaults taken from calling scope.
#' @param rtol Numeric relative tolerance for the ODE solver.
#' @param atol Numeric absolute tolerance for the ODE solver.
#' @return A `data.frame` containing the time grid and state variables.
#' @seealso create.params.chiu, create.inits.chiu, create.events.chiu, ode.func.chiu
#' @keywords internal
#' @export
#' 
.run_chiu <- function(user_input, solver = "lsodes", rtol = 1e-5, atol = 1e-5){
  params_chiu <- .create.params.chiu(user_input)
  inits_chiu <- .create.inits.chiu(params_chiu)
  events_chiu <- .create.events.chiu(params_chiu)
  solution_chiu <-  as.data.frame(deSolve::ode(times = user_input$exposure_time,  func = .ode.func.chiu, 
                                      y = inits_chiu, parms = params_chiu,
                                      events = events_chiu, method= solver, rtol = rtol, atol = atol))
  return(solution_chiu)
}


#' Run chou PBK model (internal)
#'
#' Wrapper around parameter/init/event construction for the chou model, solved via `deSolve::ode()`.
#'
#' @param user_input List with fields required by the model (e.g., `exposure_time`, dosing, BW, etc.).
#' @param solver Character or function passed to `deSolve::ode(method=)`. Defaults taken from calling scope.
#' @param rtol Numeric relative tolerance for the ODE solver.
#' @param atol Numeric absolute tolerance for the ODE solver.
#' @return A `data.frame` containing the time grid and state variables.
#' @seealso create.params.chou, create.inits.chou, create.events.chou, ode.func.chou
#' @keywords internal
#' @export
#' 
.run_chou <- function(user_input, solver = "lsodes", rtol = 1e-5, atol = 1e-5){  
  params_chou <- .create.params.chou(user_input)
  inits_chou <- .create.inits.chou(params_chou)
  events_chou <- .create.events.chou(params_chou)
  solution_chou <-  as.data.frame(deSolve::ode(times = user_input$exposure_time,  func = .ode.func.chou, 
                                      y = inits_chou, parms = params_chou,
                                      events = events_chou, method= solver, rtol = rtol, atol = atol))
  return(solution_chou)
}


#' Run Fàbrega PBK model (internal)
#'
#' Constructs inputs for the Fàbrega model and solves with `deSolve::ode()`.
#'
#' @param user_input List with fields required by the model (e.g., `exposure_time`, dosing, BW, etc.).
#' @param solver Character or function passed to `deSolve::ode(method=)`. Defaults taken from calling scope.
#' @param rtol Numeric relative tolerance for the ODE solver.
#' @param atol Numeric absolute tolerance for the ODE solver.
#' @return A `data.frame` containing the time grid and state variables.
#' @seealso create.params.fabrega, create.inits.fabrega, create.events.fabrega, ode.func.fabrega
#' @keywords internal
#' @export
#' 
.run_fabrega <- function(user_input, solver = "lsodes", rtol = 1e-5, atol = 1e-5){
  params_fabrega <- .create.params.fabrega(user_input)
  inits_fabrega <- .create.inits.fabrega(params_fabrega)
  events_fabrega <- .create.events.fabrega(params_fabrega)
  solution_fabrega <-  as.data.frame(deSolve::ode(times = user_input$exposure_time,  func = .ode.func.fabrega, 
                                         y = inits_fabrega, parms = params_fabrega,
                                         events = events_fabrega, method= solver, rtol = rtol, atol = atol))
  
  return(solution_fabrega)
}



#' Run loccisano PBK model (internal)
#'
#' Prepares the loccisano model inputs and solves using `deSolve::ode()`.
#'
#' @param user_input List with fields required by the model (e.g., `exposure_time`, dosing, BW, etc.).
#' @param solver Character or function passed to `deSolve::ode(method=)`. Defaults taken from calling scope.
#' @param rtol Numeric relative tolerance for the ODE solver.
#' @param atol Numeric absolute tolerance for the ODE solver.
#' @return A `data.frame` containing the time grid and state variables.
#' @seealso create.params.loccisano, create.inits.loccisano, create.events.loccisano, ode.func.loccisano
#' @keywords internal
#' @export
#' 
.run_loccisano <- function(user_input, solver = "lsodes", rtol = 1e-5, atol = 1e-5){
  params_loccisano <- .create.params.loccisano(user_input)
  inits_loccisano <- .create.inits.loccisano(params_loccisano)
  events_loccisano <- .create.events.loccisano(params_loccisano)
  solution_loccisano <-  as.data.frame(deSolve::ode(times = user_input$exposure_time,  func = .ode.func.loccisano, 
                                           y = inits_loccisano, parms = params_loccisano,
                                           events = events_loccisano, method= solver, rtol = rtol, atol = atol))
  
  return(solution_loccisano)
}



#' Run worley PBK model (internal)
#'
#' Sets up and solves the worley model via `deSolve::ode()`.
#'
#' @param user_input List with fields required by the model (e.g., `exposure_time`, dosing, BW, etc.).
#' @param solver Character or function passed to `deSolve::ode(method=)`. Defaults taken from calling scope.
#' @param rtol Numeric relative tolerance for the ODE solver.
#' @param atol Numeric absolute tolerance for the ODE solver.
#' @return A `data.frame` containing the time grid and state variables.
#' @seealso create.params.worley, create.inits.worley, create.events.worley, ode.func.worley
#' @keywords internal
#' @export
#' 
.run_worley <- function(user_input, solver = "lsodes", rtol = 1e-5, atol = 1e-5){
  params_worley <- .create.params.worley(user_input)
  inits_worley <- .create.inits.worley(params_worley)
  events_worley <- .create.events.worley(params_worley)
  solution_worley <-  as.data.frame(deSolve::ode(times = user_input$exposure_time,  func = .ode.func.worley, 
                                        y = inits_worley, parms = params_worley,
                                        events = events_worley, method= solver, rtol = rtol, atol = atol))
  
  return(solution_worley)
}


#' Load posterior sample dataset
#'
#' @param name One of: "serum_PFOA_sigma", "serum_PFOA_weight",
#'   "serum_PFOS_sigma", "serum_PFOS_weight",
#'   "liver_PFOA_sigma", "liver_PFOA_weight",
#'   "liver_PFOS_sigma", "liver_PFOS_weight"
#'
#' @return A data frame read from the corresponding CSV.
#' @keywords internal
#' @export
#' 
.load_posterior_samples <- function(name) {
  fname <- paste0("posterior_samples_", name, ".csv")
  path <- system.file("extdata", fname, package = "PfasDosim")
  if (path == "") stop("File not found in extdata: ", fname, call. = FALSE)
  read.csv(path, stringsAsFactors = FALSE)
}


#' Run all PBK models and assemble comparison outputs (internal)
#'
#' Executes the available PBK model wrappers for the selected chemical and
#' returns aligned serum and liver concentration time-series in tidy data frames.
#'
#' @param user_input List of model inputs; must include at least `chemical`
#'   (e.g., `"PFOA"` or `"PFOS"`) and `exposure_time` (numeric vector of times).
#' @param solver ODE solver passed to `deSolve::ode(method=)`. Defaults taken from calling scope.
#' @param rtol Relative tolerance for the ODE solver.
#' @param atol Absolute tolerance for the ODE solver.
#'
#' @return A named list with two data frames:
#' \describe{
#'   \item{serum_df}{Columns: `time` and one column per model (e.g., `Cserum_worley`,
#'     `Cserum_fabrega`, `Cserum_loccisano`, `Cserum_chiu`/`Cserum_chou`).}
#'   \item{liver_df}{Columns: `time` and one column per model (e.g., `Cliver_worley`,
#'     `Cliver_fabrega`, `Cliver_loccisano`, optionally `Cliver_chou`).}
#' }
#'
#' @seealso run_fabrega, run_loccisano, run_chiu, run_chou, run_worley
#' @keywords internal
#' @export
#' 
.run_all_models <- function(user_input, solver = "lsodes", rtol = 1e-5, atol = 1e-5 ){
  
  solution_fabrega <- .run_fabrega(user_input, solver = solver, rtol = rtol, atol = atol)
  solution_loccisano <- .run_loccisano(user_input, solver = solver, rtol = rtol, atol = atol)
  solution_chiu <- .run_chiu(user_input, solver = solver, rtol = rtol, atol = atol)
    
  chemical <- user_input$chemical
  if (user_input$free == TRUE & toupper(chemical) == "PFOS"){
    free_fabrega_serum <- 0.03
    free_loccisano_serum <- 0.025
    free_chou_serum <- 0.014
    free_worley_serum <- 1 #not applicable
    free_chiu_serum <- 0.023
    
    #free liver = free serum/PC_liver_to_serum
    free_fabrega_liver <- free_fabrega_serum/2.67
    free_loccisano_liver <- free_loccisano_serum/3.72
    free_chou_liver <- free_chou_serum/2.02
    free_worley_liver <- 1 #not applicable
    
  }else if (user_input$free == TRUE & toupper(chemical) == "PFOA"){
    free_fabrega_serum <- 0.03
    free_loccisano_serum <- 0.02
    free_chou_serum <- 1 #not applicable
    free_worley_serum <-  0.02
    free_chiu_serum <- 0.023
    
    #free liver = free serum/PC_liver_to_serum
    free_fabrega_liver <- free_fabrega_serum/1.03
    free_loccisano_liver <- free_loccisano_serum/2.2
    free_chou_liver <- 1 #not applicable
    free_worley_liver <- free_worley_serum/1.03
    
  }else{
    free_fabrega_serum <- 1
    free_loccisano_serum <- 1
    free_chou_serum <- 1
    free_worley_serum <- 1
    free_chiu_serum <- 1
    
    free_fabrega_liver <- 1
    free_loccisano_liver <- 1
    free_chou_liver <- 1
    free_worley_liver <- 1
    free_chiu_liver <- 1
  }
  
  if (toupper(chemical) == "PFOS"){

    solution_chou <- .run_chou(user_input, solver = solver, rtol = rtol, atol = atol)
  
    serum_df <- data.frame(time = solution_chou$time,   
                          "Cserum_chou" = solution_chou$Cserum*free_chou_serum,
                          "Cserum_fabrega" = solution_fabrega$Cserum*free_fabrega_serum,
                          "Cserum_loccisano" = solution_loccisano$Cserum*free_loccisano_serum,
                          "Cserum_chiu" = solution_chiu$Cserum*free_chiu_serum)
    liver_df <- data.frame(time = solution_chou$time, 
                          "Cliver_chou" = solution_chou$Cliver*free_chou_liver,
                          "Cliver_fabrega" = solution_fabrega$Cliver*free_fabrega_liver,
                          "Cliver_loccisano" = solution_loccisano$Cliver*free_loccisano_liver)
  
  }else if (toupper(chemical) == "PFOA"){
  
    solution_worley <- .run_worley(user_input, solver = solver, rtol = rtol, atol = atol)

    serum_df <- data.frame(time = solution_worley$time,   
                          "Cserum_worley" = solution_worley$Cserum*free_worley_serum,
                          "Cserum_fabrega" = solution_fabrega$Cserum*free_fabrega_serum,
                          "Cserum_loccisano" = solution_loccisano$Cserum*free_loccisano_serum,
                          "Cserum_chiu" = solution_chiu$Cserum*free_chiu_serum)
    liver_df <-  data.frame(time = solution_worley$time,
                          "Cliver_worley" = solution_worley$Cliver*free_worley_liver,
                          "Cliver_fabrega" = solution_fabrega$Cliver*free_fabrega_liver,
                          "Cliver_loccisano" = solution_loccisano$Cliver*free_loccisano_liver)
  }
  
  return(list("serum_df" = serum_df, "liver_df" = liver_df))
}



#' Bayesian model averaging of PBK predictions (internal)
#'
#' Loads posterior samples from \code{inst/extdata} via \code{load_posterior_samples()},
#' constructs model mean matrices for serum and liver, and computes BMA predictive
#' summaries under a log-normal error model using posterior weights and sigmas.
#' Parallelisation across time points is supported.
#'
#' @param user_input List with at least \code{exposure_time} (numeric vector of times)
#'   and \code{chemical} (character, typically \code{"PFOA"} or \code{"PFOS"}; case-insensitive).
#' @param models_output Output of \code{run_all_models()}, i.e., a list containing
#'   \code{serum_df} and \code{liver_df} time-series per model.
#' @param isParallel Logical; if \code{TRUE}, use \pkg{parallel} to process time points.
#' @param Nsamples Integer; number of posterior draws per time point (also used to
#'   subsample rows from the posterior objects; current implementation samples from \code{1:4000}).
#' @param n_cores Optional integer; number of worker processes. If \code{NULL} and
#'   \code{isParallel = TRUE}, defaults to \code{parallel::detectCores() - 2}.
#'
#' @details
#' Posterior artefacts are expected with the following keys:
#' \code{serum_PFOA_sigma}, \code{serum_PFOA_weight},
#' \code{serum_PFOS_sigma}, \code{serum_PFOS_weight},
#' \code{liver_PFOA_sigma}, \code{liver_PFOA_weight},
#' \code{liver_PFOS_sigma}, \code{liver_PFOS_weight}.
#' For PFOA, liver means combine loccisano, Fàbrega, and worley; serum means combine
#' worley, Fàbrega, loccisano, and chiu. For PFOS, liver means combine loccisano,
#' Fàbrega, and chou; serum means combine chou, Fàbrega, loccisano, and chiu.
#' The current implementation fills outputs inside the parallel branch.
#'
#' @return A named list with two data frames:
#' \describe{
#'   \item{\code{serum_df}}{Columns \code{time}, \code{mean}, \code{sd},
#'     \code{p1}, \code{p5}, \code{p25}, \code{p50}, \code{p75}, \code{p95}, \code{p99}.}
#'   \item{\code{liver_df}}{Same columns as \code{serum_df}.}
#' }
#'
#' @seealso load_posterior_samples, run_all_models
#' @importFrom stats rnorm quantile
#' @importFrom parallel makeCluster parLapply clusterExport stopCluster detectCores
#' @keywords internal
#' @export
#' 
.run_bma <- function(user_input, models_output, stat_sum = TRUE, Nsamples = 4000,  seed = 123){
  Nt <- length(user_input$exposure_time)
  
  if(stat_sum == FALSE){
    Ncol = Nsamples+1
  }else{
    Ncol = 10
  }
  
  bma_liver <- matrix(NA, nrow = Nt, ncol =Ncol)
  bma_serum <- matrix(NA, nrow = Nt, ncol = Ncol)
  set.seed(seed)
  if(Nsamples>4000){
    samp <- sample(1:4000,Nsamples,replace = TRUE)
  }else{
    samp <- sample(1:4000,Nsamples,replace = FALSE)
  }
  
  
  datasets <- c(
    "serum_PFOA_sigma",
    "serum_PFOA_weight",
    "serum_PFOA_alpha",
    "serum_PFOS_sigma",
    "serum_PFOS_weight",
    "serum_PFOS_alpha",
    "liver_PFOA_sigma",
    "liver_PFOA_alpha",
    "liver_PFOA_weight",
    "liver_PFOS_sigma",
    "liver_PFOS_alpha",
    "liver_PFOS_weight"
  )
  post_samples <- lapply(datasets, .load_posterior_samples)
  names(post_samples) <- datasets
  
  if (toupper(user_input$chemical) == "PFOA"){
    mu_liver <- cbind(models_output$liver_df$Cliver_loccisano, 
                      models_output$liver_df$Cliver_fabrega, models_output$liver_df$Cliver_worley)
    colnames(mu_liver) <-  c("Cliver_loccisano", "Cliver_fabrega", "Cliver_worley")
    mu_serum <- cbind(models_output$serum_df$Cserum_loccisano,
                      models_output$serum_df$Cserum_fabrega,  models_output$serum_df$Cserum_worley, 
                      models_output$serum_df$Cserum_chiu)
    
    colnames(mu_serum) <-  c( "Cserum_loccisano", "Cserum_fabrega",  "Cserum_worley","Cserum_chiu")
    
    weights_liver <- post_samples$liver_PFOA_weight[samp,]
    weights_serum <- post_samples$serum_PFOA_weight[samp,]
    sigma_liver <- post_samples$liver_PFOA_sigma[samp,]
    sigma_serum <- post_samples$serum_PFOA_sigma[samp,]
    alpha_liver <- post_samples$liver_PFOA_alpha[samp,]
    alpha_serum <- post_samples$serum_PFOA_alpha[samp,]
    
  } else if (toupper(user_input$chemical) == "PFOS") {
    mu_liver <- cbind(models_output$liver_df$Cliver_loccisano, 
                      models_output$liver_df$Cliver_fabrega, models_output$liver_df$Cliver_chou)
    colnames(mu_liver) <-  c("Cliver_loccisano", "Cliver_fabrega", "Cliver_chou")
    
    mu_serum <- cbind(models_output$serum_df$Cserum_loccisano,
                      models_output$serum_df$Cserum_fabrega,  models_output$serum_df$Cserum_chou, 
                      models_output$serum_df$Cserum_chiu)
    colnames(mu_serum) <-  c( "Cserum_loccisano", "Cserum_fabrega","Cserum_chou", "Cserum_chiu")
    
    weights_liver <- post_samples$liver_PFOS_weight[samp,]
    weights_serum <- post_samples$serum_PFOS_weight[samp,]
    sigma_liver <- post_samples$liver_PFOS_sigma[samp,]
    sigma_serum <- post_samples$serum_PFOS_sigma[samp,]
    alpha_liver<- post_samples$liver_PFOS_alpha[samp,]
    alpha_serum <- post_samples$serum_PFOS_alpha[samp,]
  }
  
  set.seed(seed)
  log_mu_liver <-  t(matrix(alpha_liver,  nrow = length(alpha_liver), ncol = dim(mu_liver)[1]))+
                    log(mu_liver %*%  t(as.matrix(weights_liver)))  
  draws_liver <- exp(matrix(rnorm(length(log_mu_liver), 
                                  mean = as.vector(log_mu_liver), 
                                  sd   = rep(sigma_liver, each= nrow(log_mu_liver))),
                            nrow = nrow(log_mu_liver), 
                            ncol = ncol(log_mu_liver)))

  log_mu_serum <- t(matrix(alpha_serum,  nrow = length(alpha_serum), ncol = dim(mu_serum)[1]))+
                   log(mu_serum %*%  t(as.matrix(weights_serum)))  
  draws_serum <- exp(matrix(rnorm(length(log_mu_serum), 
                                    mean = as.vector(log_mu_serum), 
                                    sd   = rep(sigma_serum, each= nrow(log_mu_serum))),
                              nrow = nrow(log_mu_serum), 
                              ncol = ncol(log_mu_serum)))
  
  if(stat_sum == FALSE){
    liver_df <- draws_liver
    serum_df<- draws_serum
  } else{
    
    liver_df <- t(apply(draws_liver, 1, function(x) {
      c(
        mean = mean(x, na.rm = TRUE),
        sd   = sd(x, na.rm = TRUE),
        quantile(x,
                 probs = c(0.01,0.05,0.25,0.5,0.75,0.95,0.99),
                 na.rm = TRUE)
      )
    }))
    
   
    serum_df <- t(apply(draws_serum, 1, function(x) {
      c(
        mean = mean(x, na.rm = TRUE),
        sd   = sd(x, na.rm = TRUE),
        quantile(x,
                 probs = c(0.01,0.05,0.25,0.5,0.75,0.95,0.99),
                 na.rm = TRUE)
      )
    }))
  }
  
  bma_liver <- cbind(user_input$exposure_time, liver_df)
  bma_serum <- cbind(user_input$exposure_time, serum_df)
  
  # Convert to data.frame
  bma_liver <- as.data.frame(bma_liver)
  bma_serum <- as.data.frame(bma_serum)
  
  if (user_input$free == TRUE & user_input$free_liver_from_serum == TRUE){
    bma_liver <- bma_serum
  }
  if(stat_sum == FALSE){
    # Rename columns
    stat_names <- c("time", paste0("draw_", 1:Nsamples))
    colnames(bma_liver) <- stat_names
    colnames(bma_serum) <- stat_names
  }else{
    # Rename columns
    stat_names <- c("time", "mean", "sd",  "p1", "p5", "p25", "p50", "p75", "p95", "p99")
    colnames(bma_liver) <- stat_names
    colnames(bma_serum) <- stat_names
  }

  return(list( "serum_df" = bma_serum, "liver_df" = bma_liver)) 
}


#' Forward dosimetry for a single chemical (internal)
#'
#' Orchestrates the PBK simulation suite and Bayesian model averaging for a single
#' chemical: runs \code{run_all_models()} and then \code{run_bma()}, returning both
#' the BMA summaries and the individual model trajectories.
#'
#' @param user_input List of inputs required by the PBK models; must include
#'   \code{exposure_time} and \code{chemical}.
#' @param isParallel Logical; if \code{TRUE}, enable parallel computation in BMA.
#' @param Nsamples Integer; number of posterior draws per time point (passed to BMA).
#' @param n_cores Optional integer; number of worker processes for parallel BMA.
#' @param solver ODE solver passed to \code{deSolve::ode(method=)} (forwarded to model runners).
#' @param rtol Relative tolerance for the ODE solver (forwarded).
#' @param atol Absolute tolerance for the ODE solver (forwarded).
#'
#' @return A named list with:
#' \describe{
#'   \item{\code{bma}}{Result of \code{run_bma()}, containing \code{serum_df} and \code{liver_df}.}
#'   \item{\code{single_models}}{Result of \code{run_all_models()}, including
#'     \code{serum_df} and \code{liver_df} per model.}
#' }
#'
#' @seealso run_all_models, run_bma
#' @keywords internal
#' @export
.forward_dosimetry_single_chem <- function(user_input,  Nsamples = 4000,  stat_sum = TRUE,  seed = 123, 
                                          solver = "lsodes", rtol = 1e-7, atol = 1e-7){ 
  res <- .run_all_models(user_input = user_input, solver = solver, rtol = rtol, atol = atol)
  bma <- .run_bma(user_input = user_input, models_output = res, 
                  stat_sum = stat_sum, Nsamples = Nsamples, 
                  seed = seed)
  
  return(list("bma" = bma, "single_models" = res)) 
}


#' @keywords internal
#' 
#' @export
#' 
.reverse_obj_func_models <- function(x, POD, compartment, modelID, user_input, 
                                     solver = "lsodes",  rtol = 1e-4, atol =1e-4){
  
  BW <- user_input$BW
  exposure_time <- user_input$exposure_time
  chemical <- user_input$chemical
  time_scale <- user_input$time_scale
  # Update user_input with current exposure guess
  if (time_scale == "minutes"){
    user_input$ingestion <- (1/24/60)*exp(x)*BW/1000 #ug/minute
  }else if (time_scale == "hours"){
    user_input$ingestion <- (1/24)*exp(x)*BW/1000 #ug/hour
  }else if (time_scale == "days"){
    user_input$ingestion <- exp(x)*BW/1000 #ug/day
  }else if (time_scale == "weeks"){
    user_input$ingestion <- 7*exp(x)*BW/1000 #ug/week
  }else if (time_scale == "months"){
    user_input$ingestion <- 30*exp(x)*BW/1000 #ug/month
  }else if (time_scale == "years"){
    user_input$ingestion <- 365*exp(x)*BW/1000 #ug/year
  }
  
  if (user_input$free == TRUE & toupper(chemical) == "PFOS"){
    free_fabrega_serum <- 0.03
    free_loccisano_serum <- 0.025
    free_chou_serum <- 0.014
    free_worley_serum <- 1 #not applicable
    free_chiu_serum <- 0.023
    
    #free liver = free serum/PC_liver_to_serum
    free_fabrega_liver <- free_fabrega_serum/2.67
    free_loccisano_liver <- free_loccisano_serum/3.72
    free_chou_liver <- free_chou_serum/2.02
    free_worley_liver <- 1 #not applicable
    
  }else if (user_input$free == TRUE & toupper(chemical) == "PFOA"){
    free_fabrega_serum <- 0.03
    free_loccisano_serum <- 0.02
    free_chou_serum <- 1 #not applicable
    free_worley_serum <-  0.02
    free_chiu_serum <- 0.023
    
    #free liver = free serum/PC_liver_to_serum
    free_fabrega_liver <- free_fabrega_serum/1.03
    free_loccisano_liver <- free_loccisano_serum/2.2
    free_chou_liver <- 1 #not applicable
    free_worley_liver <- free_worley_serum/1.03
    
  }else{
    free_fabrega_serum <- 1
    free_loccisano_serum <- 1
    free_chou_serum <- 1
    free_worley_serum <- 1
    free_chiu_serum <- 1
    
    free_fabrega_liver <- 1
    free_loccisano_liver <- 1
    free_chou_liver <- 1
    free_worley_liver <- 1
    free_chiu_liver <- 1
  }
  
  if(tolower(modelID) == "fabrega"){
    solution <- .run_fabrega(user_input, solver = solver, rtol = rtol, atol = atol)
    solution$Cliver <- solution$Cliver*free_fabrega_liver
    solution$Cserum <- solution$Cserum*free_fabrega_serum
  }else if(tolower(modelID) == "loccisano"){
    solution <- .run_loccisano(user_input, solver = solver, rtol = rtol, atol = atol)
    solution$Cliver <- solution$Cliver*free_loccisano_liver
    solution$Cserum <- solution$Cserum*free_loccisano_serum
  }else if(tolower(modelID) == "chiu"){
    solution <- .run_chiu(user_input, solver = solver, rtol = rtol, atol = atol)
    solution$Cserum <- solution$Cserum*free_chiu_serum
  }else if(tolower(modelID) == "worley"){
    solution <- .run_worley(user_input, solver = solver, rtol = rtol, atol = atol)
    solution$Cliver <- solution$Cliver*free_worley_liver
    solution$Cserum <- solution$Cserum*free_worley_serum
  }else if(tolower(modelID) == "chou"){
    solution <- .run_chou(user_input, solver = solver, rtol = rtol, atol = atol)
    solution$Cliver <- solution$Cliver*free_chou_liver
    solution$Cserum <- solution$Cserum*free_chou_serum
  }

  
  if(  toupper(compartment) =="LIVER"){
    final_concentration <- tail(solution,1)$Cliver
  }else if (toupper(compartment) == "SERUM"){
    final_concentration <- tail(solution,1)$Cserum
  } 
 
  rel_error <- abs((final_concentration - POD) / POD)
  
  return(rel_error)
  
}

#' @keywords internal
#' @export
.reverse_obj_func_bma <- function(x, POD, compartment, user_input, model_weights,
                                  error = 0, alpha = 0, sigma_eff = 0.2,
                                  solver = "lsodes",  rtol = 1e-4, atol =1e-4) {
  
  BW          <- user_input$BW
  exposure_time <- user_input$exposure_time
  chemical    <- user_input$chemical
  time_scale  <- user_input$time_scale
  
  # Update user_input with current exposure guess (x is log-exposure)
  if (time_scale == "minutes") {
    user_input$ingestion <- (1 / 24 / 60) * exp(x) * BW / 1000  # µg/min
  } else if (time_scale == "hours") {
    user_input$ingestion <- (1 / 24) * exp(x) * BW / 1000       # µg/h
  } else if (time_scale == "days") {
    user_input$ingestion <- exp(x) * BW / 1000                  # µg/day
  } else if (time_scale == "weeks") {
    user_input$ingestion <- 7 * exp(x) * BW / 1000              # µg/week
  } else if (time_scale == "months") {
    user_input$ingestion <- 30 * exp(x) * BW / 1000             # µg/month
  } else if (time_scale == "years") {
    user_input$ingestion <- 365 * exp(x) * BW / 1000            # µg/year
  }
  
  # Run PBK models
  model_results <- .run_all_models(user_input, solver = solver, rtol = rtol, atol = atol)
  
  # Extract terminal concentrations per model
  if (toupper(compartment) == "LIVER") {
    
    if (toupper(chemical) == "PFOS") {
      last_point <- t(as.matrix(
        tail(model_results$liver_df, 1)[c("Cliver_loccisano",
                                          "Cliver_fabrega",
                                          "Cliver_chou")],
        ncol = 1
      ))
    } else if (toupper(chemical) == "PFOA") {
      last_point <- t(as.matrix(
        tail(model_results$liver_df, 1)[c("Cliver_loccisano",
                                          "Cliver_fabrega",
                                          "Cliver_worley")],
        ncol = 1
      ))
    }
    
  } else if (toupper(compartment) == "SERUM") {
    
    if (toupper(chemical) == "PFOS") {
      last_point <- t(as.matrix(
        tail(model_results$serum_df, 1)[c("Cserum_loccisano",
                                          "Cserum_fabrega",
                                          "Cserum_chou",
                                          "Cserum_chiu")],
        ncol = 1
      ))
    } else if (toupper(chemical) == "PFOA") {
      last_point <- t(as.matrix(
        tail(model_results$serum_df, 1)[c("Cserum_loccisano",
                                          "Cserum_fabrega",
                                          "Cserum_worley",
                                          "Cserum_chiu")],
        ncol = 1
      ))
    }
    
  } else {
    stop("compartment must be 'LIVER' or 'SERUM'")
  }
  
  # BMA prediction
  # There is a small bias here affecting mainly PFOA liver, because alpha in PFOA liver has
  # a bigger spread compared to other compartments. Thus, it does not exactly match the forward
  # dosimetry component, because there we use all posterior draws and Eexp(alpha)]>exp(E[alpha]) (Jensen’s inequality).
  final_concentration <- exp(alpha) * as.numeric(model_weights %*% last_point) * exp(0.5 * sigma_eff^2)
  
  # If error != 0, adjust POD as C_obs = C_pred * exp(error) => Cpred = C_obs*exp(-error)
  POD_adj <- POD * exp(-error)
  
  # Relative error
  rel_error <- abs((final_concentration - POD_adj) / POD_adj)
  
  
  
  return(rel_error)
}


#' @export
.reverse_dosimetry_bma <- function(user_input, bmd_df_row, post_samples,
                                  isParallel =TRUE, isStochastic =FALSE, Nsamples =10, 
                                  n_cores = NULL, stat_sum = FALSE, seed =123,
                                  optim_tol =1e-3, solver = "lsodes",  rtol = 1e-4, atol =1e-4) {
  
  BW            <- user_input$BW
  exposure_time <- user_input$exposure_time
  chemical      <- user_input$chemical
  POD           <- bmd_df_row$POD
  compartment   <- bmd_df_row$compartment
  if (user_input$free == TRUE & user_input$free_liver_from_serum == TRUE){
    compartment <- "SERUM"
  }
  # --------------------------------------------------------------------------
  # NON-STOCHASTIC MODE 
  # --------------------------------------------------------------------------
  if (!isStochastic) {
    
    if (toupper(chemical) == "PFOA") {
      if (toupper(compartment) == "LIVER") {
        model_weights <- apply(post_samples$liver_PFOA_weight, 2, mean)
        alpha <- apply(post_samples$liver_PFOA_alpha  , 2, mean)
        sigma_eff<- apply(post_samples$liver_PFOA_sigma, 2, mean)
      } else if (toupper(compartment) == "SERUM") {
        model_weights <- apply(post_samples$serum_PFOA_weight, 2, mean)
        alpha <- apply(post_samples$serum_PFOA_alpha  , 2, mean)
        sigma_eff<- apply(post_samples$serum_PFOA_sigma, 2, mean)
      } else {
        stop("Unknown compartment for PFOA in reverse_dosimetry_bma.")
      }
      
    } else if (toupper(chemical) == "PFOS") {
      if (toupper(compartment) == "LIVER") {
        model_weights <- apply(post_samples$liver_PFOS_weight, 2, mean)
        alpha <- apply(post_samples$liver_PFOS_alpha  , 2, mean)
        sigma_eff<- apply(post_samples$liver_PFOS_sigma, 2, mean)
      } else if (toupper(compartment) == "SERUM") {
        model_weights <- apply(post_samples$serum_PFOS_weight, 2, mean)
        alpha <- apply(post_samples$serum_PFOS_alpha  , 2, mean)
        sigma_eff<- apply(post_samples$serum_PFOS_sigma, 2, mean)
        
      } else {
        stop("Unknown compartment for PFOS in reverse_dosimetry_bma.")
      }
      
    } else {
      stop("Unknown chemical in reverse_dosimetry_bma.")
    }
    
    # nloptr options
    opts <- list(
      "algorithm"   = "NLOPT_LN_SBPLX",
      "xtol_rel"    = optim_tol,
      "xtol_abs"    = optim_tol,
      "ftol_rel"    = optim_tol,
      "ftol_abs"    = optim_tol,
      "maxeval"     = 1000,
      "print_level" = 0
    )
    
    optimizer <- nloptr::nloptr(
      x0   = 1,
      eval_f = .reverse_obj_func_bma,
      lb   = -15,
      ub   = 15,
      opts = opts,
      POD         = POD,
      compartment = compartment,
      user_input  = user_input,
      model_weights = model_weights,
      alpha = alpha,
      error       = 0,
      sigma_eff   = sigma_eff,
      solver      = solver,
      atol        = atol,
      rtol        = rtol
    )
    
    exposure  <- exp(optimizer$solution)
    rel_error <- optimizer$objective
    
    return(list(
      exposure    = exposure,
      rel_error   = rel_error,
      POD         = POD,
      compartment = compartment,
      key_event   = bmd_df_row$key_event,
      time        = bmd_df_row$time
    ))
  }
  
  # --------------------------------------------------------------------------
  # STOCHASTIC MODE (BMA sampling over weights + error)
  # --------------------------------------------------------------------------
  # Select posterior matrices
  if (toupper(chemical) == "PFOA") {
    if (toupper(compartment) == "LIVER") {
      W <- post_samples$liver_PFOA_weight
      S <- post_samples$liver_PFOA_sigma
      alpha <- post_samples$liver_PFOA_alpha
      sigma_eff<- apply(post_samples$liver_PFOA_sigma, 2, mean)
    } else if (toupper(compartment) == "SERUM") {
      W <- post_samples$serum_PFOA_weight
      S <- post_samples$serum_PFOA_sigma
      alpha <- post_samples$serum_PFOA_alpha
      sigma_eff<- apply(post_samples$serum_PFOA_sigma, 2, mean)
    } else {
      stop("Unknown compartment for PFOA in stochastic reverse_dosimetry_bma.")
    }
    
  } else if (toupper(chemical) == "PFOS") {
    if (toupper(compartment) == "LIVER") {
      W <- post_samples$liver_PFOS_weight
      S <- post_samples$liver_PFOS_sigma
      alpha <- post_samples$liver_PFOS_alpha
      sigma_eff<- apply(post_samples$liver_PFOS_sigma, 2, mean)
      
    } else if (toupper(compartment) == "SERUM") {
      W <- post_samples$serum_PFOS_weight
      S <- post_samples$serum_PFOS_sigma
      alpha <- post_samples$serum_PFOS_alpha
      sigma_eff<- apply(post_samples$serum_PFOS_sigma, 2, mean)
      
    } else {
      stop("Unknown compartment for PFOS in stochastic reverse_dosimetry_bma.")
    }
    
  } else {
    stop("Unknown chemical in stochastic reverse_dosimetry_bma.")
  }
  
  W <- as.matrix(W)
  S <- as.numeric(unlist(S))
  alpha <- as.numeric(unlist(alpha))
  
  n_post <- nrow(W)
  if (is.null(Nsamples) || Nsamples <= 0) {
    stop("Nsamples must be a positive integer in stochastic reverse_dosimetry_bma.")
  }
  
  set.seed(seed)
  # Sample posterior indices for BMA draws
  if (Nsamples <= n_post) {
    samp_idx <- sample(seq_len(n_post), Nsamples, replace = FALSE)
  } else {
    samp_idx <- sample(seq_len(n_post), Nsamples, replace = TRUE)
  }
  
  W <- W[samp_idx, , drop = FALSE]
  S <- S[samp_idx]
  alpha <- alpha[samp_idx]
  # nloptr options
  opts <- list(
    "algorithm"   = "NLOPT_LN_SBPLX",
    "xtol_rel"    = optim_tol,
    "xtol_abs"    = optim_tol,
    "ftol_rel"    = optim_tol,
    "ftol_abs"    = optim_tol,
    "maxeval"     = 1000,
    "print_level" = 0
  )
  if (!isParallel) {
    set.seed(seed)
    par_res <- vector("list", Nsamples)
    for (k in 1:Nsamples){
      w_k <- W[k, ]
      s_k <- S[k]
      alpha_k <- alpha[k]
      err_k <- stats::rnorm(1, mean = 0, sd = s_k)
      opt <- nloptr::nloptr(
        x0   = 1,
        eval_f = .reverse_obj_func_bma,
        lb   = -15,
        ub   = 15,
        opts = opts,
        POD         = POD,
        compartment = compartment,
        user_input  = user_input,
        model_weights = w_k,
        error       = err_k,
        alpha       = alpha_k,
        sigma_eff   = 0,
        solver      = solver,
        atol        = atol,
        rtol        = rtol
      )
      par_res[[k]] = list(
                          exposure  =  exp(opt$solution),
                          rel_error = opt$objective
                        )
      
    }
    exposure_draws  <- vapply(par_res, `[[`, numeric(1), "exposure")
    rel_error_draws <- vapply(par_res, `[[`, numeric(1), "rel_error")
  }else{
    
    if (is.null(n_cores)) {
      n_cores <- parallel::detectCores() - 2
    }
    
    cl <- parallel::makeCluster(n_cores)
    
    parallel::clusterEvalQ(cl, {
      library(nloptr)
    })
    
    parallel::clusterExport(
      cl,
      varlist = c(".reverse_obj_func_bma", ".run_all_models",
                  ".run_fabrega", ".run_loccisano", ".run_worley", ".run_chou", ".run_chiu",
                  ".create.params.fabrega", ".create.inits.fabrega", ".create.events.fabrega", 
                  ".create.params.loccisano", ".create.inits.loccisano", ".create.events.loccisano",
                  ".create.params.worley", ".create.inits.worley", ".create.events.worley", 
                  ".create.params.chou", ".create.inits.chou",  ".create.events.chou",  
                  ".create.params.chiu", ".create.inits.chiu", ".create.events.chiu",
                  ".ode.func.loccisano", ".ode.func.fabrega", ".ode.func.worley", 
                  ".ode.func.chou", ".ode.func.chiu",
                  "POD", "compartment", "user_input",
                  "solver", "rtol", "atol", "W", "S", "alpha", "opts"),
      envir = environment()
    )
    
    parallel::clusterSetRNGStream(cl, iseed = seed)
    
    par_res <- parallel::parLapply(
      cl,
      X = seq_len(Nsamples),
      fun = function(k) {
        w_k <- W[k, ]
        s_k <- S[k]
        alpha_k <- alpha[k]
        err_k <- stats::rnorm(1, mean = 0, sd = s_k)
        
        opt <- nloptr::nloptr(
          x0   = 1,
          eval_f = .reverse_obj_func_bma,
          lb   = -15,
          ub   = 15,
          opts = opts,
          POD         = POD,
          compartment = compartment,
          user_input  = user_input,
          model_weights = w_k,
          error       = err_k,
          alpha       = alpha_k,
          sigma_eff   = 0,
          solver      = solver,
          atol        = atol,
          rtol        = rtol
          )
        
        list(
          exposure  = exp(opt$solution),
          rel_error = opt$objective
        )
      }
    )
    
    parallel::stopCluster(cl)
    
    exposure_draws  <- vapply(par_res, `[[`, numeric(1), "exposure")
    rel_error_draws <- vapply(par_res, `[[`, numeric(1), "rel_error")
  }
  
  # --------------------------------------------------------------------------
  # stat_sum logic:
  #   - stat_sum = FALSE → return full draws
  #   - stat_sum = TRUE → return summary stats (like run_bma)
  # --------------------------------------------------------------------------
  if (!stat_sum) {
    exposure  <- exposure_draws
    rel_error <- rel_error_draws
    
  } else {
    qs <- c(0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99)
    
    # Exposure summaries
    ex_q <- stats::quantile(exposure_draws, probs = qs, na.rm = TRUE)
    exposure <- c(
      mean = mean(exposure_draws, na.rm = TRUE),
      sd   = stats::sd(exposure_draws, na.rm = TRUE),
      setNames(ex_q, c("p1", "p5", "p25", "p50", "p75", "p95", "p99"))
    )
    
    # rel_error summaries
    re_q <- stats::quantile(rel_error_draws, probs = qs, na.rm = TRUE)
    rel_error <- c(
      mean = mean(rel_error_draws, na.rm = TRUE),
      sd   = stats::sd(rel_error_draws, na.rm = TRUE),
      setNames(re_q, c("p1", "p5", "p25", "p50", "p75", "p95", "p99"))
    )
  }
  
  
  
  return(list(
    exposure    = exposure,
    rel_error   = rel_error,
    POD         = POD,
    compartment = compartment,
    key_event   = bmd_df_row$key_event,
    time        = bmd_df_row$time
  ))
}

#' 
#' @export
.reverse_dosimetry_models <- function(user_input , bmd_df_row,
                                  optim_tol =1e-3 , solver ="lsodes" , rtol=1e-4 , atol =1e-4 ) {
  
  BW <- user_input$BW
  exposure_time <- user_input$exposure_time
  chemical <- user_input$chemical
  POD <-  bmd_df_row$POD
  compartment <- bmd_df_row$compartment
  bmd_time <- bmd_df_row$time
  
  #Initialise optimiser to NULL for better error handling later
  opts <- list(
    "algorithm"  = "NLOPT_LN_SBPLX",   # or "NLOPT_LN_NEWUOA" for smooth functions
    "xtol_rel"   = optim_tol,               # relative tolerance in x (e.g., stop if Δx/x < 0.1%)
    "xtol_abs"   = optim_tol,               # absolute tolerance in x (e.g., stop if Δx < 0.001)
    "ftol_rel"   = optim_tol,               # relative tolerance in objective (e.g., stop if error stops improving)
    "ftol_abs"   = optim_tol,               # absolute tolerance in objective (e.g., stop if error < 0.01)
    "maxeval"    = 1000,           # number of allowed function evaluations
    "print_level"= 0                  # change to 1 if you want progress output
  )
  
  
  exposure <-list("fabrega" = NULL, "loccisano" = NULL, "chou" = NULL,
                  "chiu" = NULL, "worley" = NULL)
  rel_error <-list("fabrega" = NULL, "loccisano" = NULL, "chou" = NULL,
                  "chiu" = NULL, "worley" = NULL)
  if(toupper(chemical) == "PFOA"){
    if(toupper(compartment) == "LIVER"){
      model_names <- c("loccisano", "fabrega", "worley")
    }else if(toupper(compartment) == "SERUM"){
      model_names <- c("loccisano", "fabrega", "worley", "chiu")
    }
  }else if (toupper(chemical) == "PFOS"){
    if(toupper(compartment) == "LIVER"){
      model_names <- c("loccisano", "fabrega", "chou")
  }else if(toupper(compartment) == "SERUM"){
      model_names <- c("loccisano", "fabrega", "chou", "chiu")
    }
  }
  
  for (model_name in model_names){
    optimizer <- nloptr::nloptr(
      x0 = 1,
      eval_f = .reverse_obj_func_models,
      lb = -8,
      ub = 8,
      opts = opts,
      POD = POD,
      compartment = compartment,
      modelID = model_name,
      user_input = user_input,
      solver = solver, atol = atol, rtol = rtol
    )
    
    exposure[[model_name]] <- exp(optimizer$solution)
    rel_error[[model_name]] <- optimizer$objective
  }
  
  exposure_fabrega <- exposure[["fabrega"]] 
  exposure_loccisano <- exposure[["loccisano"]] 
  exposure_chou <- exposure[["chou"]]
  exposure_chiu <- exposure[["chiu"]]
  exposure_worley <- exposure[["worley"]]
  
  rel_error_fabrega <- rel_error[["fabrega"]]
  rel_error_loccisano <- rel_error[["loccisano"]]
  rel_error_chou <- rel_error[["chou"]]
  rel_error_chiu <- rel_error[["chiu"]]
  rel_error_worley <- rel_error[["worley"]]
  
  return(list("exposure" = list("exposure_fabrega" = exposure[["fabrega"]], 
              "exposure_loccisano" = exposure[["loccisano"]],
              "exposure_chou" = exposure[["chou"]],
              "exposure_chiu" = exposure[["chiu"]],
              "exposure_worley" = exposure[["worley"]]),
              
              "rel_error" = list("rel_error_fabrega" = rel_error[["fabrega"]], 
              "rel_error_loccisano" = rel_error[["loccisano"]],
              "rel_error_chou" = rel_error[["chou"]],
              "rel_error_chiu" = rel_error[["chiu"]],
              "rel_error_worley" = rel_error[["worley"]]),
              
               "POD" = POD,
              "compartment" = compartment, "key_event" = bmd_df_row$key_event,
              "time" = bmd_df_row$time))
}

#########
# Input
########



#' @export
.reverse_dosimetry_single_chem <- function(user_input , bmd_df,
                                          isParallel =TRUE, isStochastic =FALSE, Nsamples =10, 
                                          n_cores = 1, stat_sum = FALSE, seed =123,
                                          optim_tol =1e-3 , solver ="lsodes" , rtol=1e-4 , atol =1e-4 ){
  
  datasets <- c(
    "serum_PFOA_sigma",
    "serum_PFOA_weight",
    "serum_PFOA_alpha",
    "serum_PFOS_sigma",
    "serum_PFOS_weight",
    "serum_PFOS_alpha",
    "liver_PFOA_sigma",
    "liver_PFOA_alpha",
    "liver_PFOA_weight",
    "liver_PFOS_sigma",
    "liver_PFOS_alpha",
    "liver_PFOS_weight"
  )
  
  post_samples <- lapply(datasets, .load_posterior_samples)
  names(post_samples) <- datasets
  
  N_KE <- dim(bmd_df)[1]
  results <- list()
  
  for (k in 1:N_KE){
    bmd_df_row <- bmd_df[k,]
    model_res <- .reverse_dosimetry_models(user_input , bmd_df_row,
                                                   optim_tol , solver , rtol , atol ) 
    bma_res <- .reverse_dosimetry_bma(user_input, bmd_df_row, post_samples,
                                     isParallel ,isStochastic, Nsamples , n_cores ,stat_sum, seed,
                                                    optim_tol , solver , rtol , atol)
      
    results[[bmd_df_row$key_event]] <- list("bma" = bma_res, "single_models" = model_res)
  }
     
    return(results)
}

