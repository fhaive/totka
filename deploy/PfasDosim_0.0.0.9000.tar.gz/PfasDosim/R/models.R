#############
# chiu model
############
#' @export
#'  

.create.params.chiu  <- function(user_input){
  with( as.list(user_input),{
    # Vd: L/kg
    # initial T1/2:years
    
    #Initial time: years
    if  (missing(time_scale) || is.na(time_scale)){
      time_scale <- 365
    }
    else if (time_scale == "minutes"){
      time_scale <- 365*24*60
    }else if (time_scale == "hours"){
      time_scale <- 365*24
    }else if (time_scale == "days"){
      time_scale <- 365
    }else if (time_scale == "weeks"){
      time_scale <- 365/7
    }else if (time_scale == "months"){
      time_scale <- 12
    }else if (time_scale == "years"){
      time_scale <- 1
    }
    
    if (chemical == "PFOA"){
      Vd <- 0.43 * BW
      T_half <-  3.14*time_scale
      k <-   log(2)/T_half 
    }else if (chemical == "PFOS"){
      Vd <- 0.32* BW
      T_half <- 3.36*time_scale
      k <- log(2)/T_half
    }else if (chemical == "PFNA"){
      Vd <- 0.19* BW
      T_half <- 2.35*time_scale
      k <- log(2)/T_half
    }else if (chemical == "PFHxS"){
      Vd <- 0.29* BW
      T_half <- 8.30*time_scale
      k <- log(2)/T_half
    }
    
    return(list("BW" = BW, "Vd" = Vd, "k"  = k,
                "ingestion" = ingestion,
                "ingestion_time" = ingestion_time,
                "admin_dose" = admin_dose, "admin_time" = admin_time,
                "admin_type" = admin_type, "exp_type" = exp_type
    ))
    
  })
}

#===============================================
#2. Function to create initial values for ODEs 
#===============================================
#' 
#' @export
#'   
.create.inits.chiu <- function(parameters){
  with( as.list(parameters),{
    Cserum <- 0
    ingestion<- 0
    return(c("Cserum" = Cserum, "ingestion" = ingestion))
  })
}

#===================
#3. Events function
#===================
#' 
#' @export
#'  
.create.events.chiu <- function(parameters){
  with(as.list(parameters), {
    if (tolower(admin_type) == "iv"){
      # Calculate number of administrated doses and corresponding administration time for IV
      ldose <- length(admin_dose)
      ltimes <- length(admin_time)
      # If not equal, then stop 
      if (ltimes != ldose){
        stop("The times of administration should be equal in number to the doses")
      }else{
        events <- list(data = rbind(data.frame(var = c("Cserum"),  time = admin_time, 
                                               value = admin_dose/Vd, method = c("add")) ))
      }
    }else{
      lingest <- length(ingestion)
      lingesttimes <- length(ingestion_time)
      # If not equal, then stop 
      if (lingest != lingesttimes){
        stop("The times of ingestion rate change should be equal to the ingestion time vector")
      }else{
        if(exp_type == "pharmacokinetics"){
          events <- list(data = data.frame(var = c("Cserum"),  time = ingestion_time, 
                                           value = ingestion/Vd, method = c("add")))
        }else{
          events <- list(data = data.frame(var = c("ingestion"),  time = ingestion_time, 
                                           value = ingestion, method = c("rep")))
        }
      }
      
    }
    
    return(events)
  })
}

#==================
#4. Custom function 
#==================
#' 
#' @export
#' 
.custom.func <- function(){
  return()
}

#==============
#5. ODEs System
#==============
#'  
#' @export
#'  
.ode.func.chiu <- function(time, inits, params, custom.func){
  with(as.list(c(inits,params)),{
    # Cserum: in ug/L, time in days
    dCserum <- ingestion/Vd - k*Cserum 
    dingestion <- 0
    list(c( "dCserum"  =  dCserum,  "dingestion" = dingestion))
    
  })
}



#############
# chou model
############
#'  
#' @export
#'  
.create.params.chou  <- function(user_input){
  with( as.list(user_input),{
    # User input: BW(kg)
    #Initial time: hours
    if  (missing(time_scale) || is.na(time_scale)){
      time_scale <- 1/24
    }else if (time_scale == "minutes"){
      time_scale <- 60
    }else if (time_scale == "hours"){
      time_scale <- 1
    }else if (time_scale == "days"){
      time_scale <- 1/24
    }else if (time_scale == "weeks"){
      time_scale <- (1/24)/7
    }else if (time_scale == "months"){
      time_scale <- ((1/24)/30)
    }else if (time_scale == "years"){
      time_scale <- ((1/24)/365)
    }
    inv_time_scale <- 1/time_scale
    
    
    #Cardiac Output and plasmaflow (as fraction of cardiac output)
    QCC = 12.5*inv_time_scale #cardiac output in L/time_scale/kg^0.75; Brown 1997		 
    QLC = 0.25 #fraction plasma flow to liver; Brown 1997	
    QKC = 0.175 #fraction plasma flow to kidney; Brown 1997.
    Htc = 0.44 #hematocrit for the rat; Davies 1993
    
    #Tissue Volumes 
    VplasC = 0.0428 #fraction vol. of plasma (L/kg BW); Davies 1993
    VLC = 0.026 #fraction vol. of liver (L/kg BW); Brown 1997
    VKC = 0.004 #fraction vol. of kidney (L/kg BW); Brown 1997
    VfilC = 4e-4	#fraction vol. of filtrate (L/kg BW)
    VPTCC = 1.35e-4 #vol. of proximal tubule cells (L/g kidney) (60 million PTC cells/gram kidney, 1 PTC = 2250 um3)
    
    #Chemical Specific Parameters
    MW = 500.126	#PFOS molecular mass (g/mol)
    
    Free = 0.014#0.006 #free fraction in plasma (male)
    
    #Kidney Transport Parameters
    Vmax_baso_invitro = 479#Vmax of basolateral transporter (pmol/mg protein/min); averaged in vitro value of OAT1 and OAT3 from Nakagawa, 2007
    Km_baso = 20100 #Km of basolateral transporter (ug/L) Average of OAT1 and OAT3 from Nakagawa et. al, 2007
    Vmax_apical_invitro = 51803 #Vmax of apical transporter (pmol/mg protein/min); invitro value for OAT4 from Yang et al, 2010
    Km_apical = 64400#Km of apical transporter (ug/L), in vitro value for OAT4 and URAT1 from Yang et al, 2010.
    RAFbaso = 1	#relative activity factor, basolateral transporters (male) (fit to data)	
    RAFapi = 0.001	#relative activity factor, apical transporters (male) (fit to data)	
    protein = 2.0e-6	#amount of protein in proximal tubule cells (mg protein/proximal tubule cell)
    GFRC = 24.19*inv_time_scale	#glomerular filtration rate (L/time_scale/kg kidney) (male); Corley, 2005
    
    #Partition Coefficients (from rat tissue data, Kudo et al, 2007)
    PL = 2.02 #liver:plasma
    PK = 1.26 #kidney:plasma
    PR = 0.2 #rest of body:plasma
    
    #rate constants
    kdif = 0.001*inv_time_scale	#diffusion rate from proximal tubule cells (L/time_scale)
    kabsc = 2.12*inv_time_scale	#rate of absorption of chemical from small intestine to liver (1/(time_scale*BW^0.25))(fit to data)
    kunabsc = 7.05e-5*inv_time_scale	#rate of unabsorbed dose to appear in feces (1/(time_scale*BW^0.25))(fit to data)
    GEC = 3.5*inv_time_scale#gastric emptying time (1/(time_scale*BW^0.25)); from Yang, 2013
    k0C = 1.0*inv_time_scale	#rate of uptake from the stomach into the liver (1/(time_scale*BW^0.25)) (fit to data)
    
    keffluxc =0.15*inv_time_scale #rate of clearance of PFOS from proximal tubule cells into plasma (1/(time_scale*BW^0.25))
    kbilec =1.3e-4*inv_time_scale #biliary elimination rate ((male); liver to feces storage (1/(time_scale*BW^0.25)) (fit to data)
    kurinec = 0.096*inv_time_scale #rate of urine elimination from urine storage (male) (1/(time_scale*BW^0.25))(fit to data)
    kvoid = 0.06974*inv_time_scale  #daily urine volume rate (L/time_scale); Van Haarst, 2004                                                   
    
    #Scaled Parameters
    #Cardiac output and plasma flows
    QC = QCC*(BW^0.75)*(1-Htc)	#cardiac output in L/time_scale; adjusted for plasma
    QK = (QKC*QC)	#plasma flow to kidney (L/time_scale)
    QL = (QLC*QC)	#plasma flow to liver (L/time_scale)
    QR = QC - QK - QL 	#plasma flow to rest of body (L/time_scale)
    QBal = QC - (QK + QL + QR) #Balance check of plasma flows; should equal zero
    
    #Tissue Volumes
    
    VPlas = VplasC*BW 	#volume of plasma (L) 
    VK = VKC*BW 	#volume of kidney (L)
    MK = VK*1.0*1000	#mass of the kidney (g)
    VKb = VK*0.16	#volume of blood in the kidney (L); fraction blood volume of kidney (0.16) from Brown, 1997
    Vfil = VfilC*BW	#volume of filtrate (L)
    VL = VLC*BW	#volume of liver (L)
    ML = VL*1.05*1000	#mass of the liver (g)
    MKC <-  0.0084 # Fraction mass of kidny (percent of BW); Brown, 1997
    #Kidney Parameters
    
    PTC = MKC*1000*6e7	#number of PTC (cells/kg BW) (based on 60 million PTC/gram kidney, assuming density of 1 kg/L)
    VPTC = VK*1000*VPTCC	#volume of proximal tubule cells (L)	
    MPTC = VPTC*1000 #mass of the proximal tubule cells (g) (assuming density 1 kg/L)	
    VR = (0.93*BW) - VPlas - VPTC - Vfil - VL	#volume of remaining tissue (L); 
    VBal = (0.93*BW) - (VR + VL + VPTC + Vfil + VPlas)	#Balance check of tissue volumes; should equal zero 
    
    Vmax_basoC = (Vmax_baso_invitro*RAFbaso*PTC*protein*60*(MW/1e12)*1e6)*inv_time_scale#Vmax of basolateral transporters (ug/time_scale/kg BW)
    Vmax_apicalC = (Vmax_apical_invitro*RAFapi*PTC*protein*60*(MW/1e12)*1e6)*inv_time_scale #Vmax of basolateral transporters (ug/time_scale/kg BW)
    Vmax_baso = Vmax_basoC*BW^0.75	#(ug/time_scale)
    Vmax_apical = Vmax_apicalC*BW^0.75	#(ug/time_scale)
    kbile = kbilec*BW^(-0.25)	#biliary elimination; liver to feces storage (/time_scale)
    kurine = kurinec*BW^(-0.25)	#urinary elimination, from filtrate (/time_scale)
    kefflux = keffluxc*BW^(-0.25)	#efflux clearance rate, from PTC to plasma (/time_scale)
    GFR = GFRC*VK	#glomerular filtration rate, scaled to mass of kidney(in kg)(L/time_scale)
    
    #GI Tract Parameters
    kabs = kabsc*BW^(-0.25)	#rate of absorption of chemical from small intestine to liver (/time_scale)
    kunabs = kunabsc*BW^(-0.25)	#rate of unabsorbed dose to appear in feces (/time_scale)
    GE = GEC*BW^(-0.25)	#gastric emptying time (/time_scale)
    k0 = k0C*BW^(-0.25) 	#rate of uptake from the stomach into the liver (/time_scale)
    
    return(list( "Free" = Free, "QC" = QC, "QK" = QK, "QL" = QL, "QR" = QR, 
                 "VPlas" = VPlas,
                 "VKb" = VKb, "Vfil" = Vfil, "VL" = VL, "VR" = VR, "ML" = ML,
                 "VPTC" = VPTC, "Vmax_baso" = Vmax_baso, "Vmax_apical" = Vmax_apical,
                 'kdif' = kdif, "Km_baso" = Km_baso, "Km_apical" = Km_apical,
                 "kbile" = kbile, "kurine" = kurine, "kefflux" = kefflux,
                 "GFR" = GFR, "kabs" = kabs, "kunabs" = kunabs, "GE" = GE, "k0" = k0,
                 "PL" = PL, "PK" = PK, "PR" = PR, "kvoid" = kvoid,
                 "ingestion" = ingestion, "ingestion_time" = ingestion_time,
                 "admin_dose" = admin_dose, "admin_time" = admin_time,
                 "admin_type" = admin_type, "exp_type" = exp_type
    ))
    
  })
}

#===============================================
#2. Function to create initial values for ODEs 
#===============================================
#'  
#' @export
#'  
.create.inits.chou <- function(parameters){
  with( as.list(parameters),{
    "AR" = 0; "Adif" = 0; "A_baso" = 0; "AKb" = 0;
    "ACl" = 0; "Aefflux" = 0;
    "A_apical" = 0; "APTC" = 0; "Afil" = 0;
    "Aurine" = 0; "AST" = 0;
    "AabsST" = 0; "ASI" = 0; "AabsSI" = 0; "Afeces" = 0;
    "AL" = 0; "Abile" = 0; "Aplas" = 0;
    "ingestion" = 0;
    
    return(c("AR" = AR, "Adif" = Adif, "A_baso" = A_baso, "AKb" = AKb,
             "ACl" = ACl, "Aefflux" = Aefflux,
             "A_apical" = A_apical, "APTC" = APTC, "Afil" = Afil,
             "Aurine" = Aurine, "AST" = AST,
             "AabsST" = AabsST, "ASI" = ASI, "AabsSI" = AabsSI, "Afeces" = Afeces, 
             "AL" = AL, "Abile" = Abile, "Aplas" = Aplas,
             "ingestion" = ingestion))
  })
}

#===================
#3. Events function
#===================
#'  
#' @export
#'  
.create.events.chou <- function(parameters){
  with(as.list(parameters), {
    if (tolower(admin_type) == "iv"){
      # Calculate number of administrated doses and corresponding administration time for IV
      ldose <- length(admin_dose)
      ltimes <- length(admin_time)
      # If not equal, then stop 
      if (ltimes != ldose){
        stop("The times of administration should be equal in number to the doses")
      }else{
        
        events <- list(data = rbind(data.frame(var = c("Aplas"),  time = admin_time, 
                                               value = admin_dose, method = c("add")) ))
      }
    }else{
      lingest <- length(ingestion)
      lingesttimes <- length(ingestion_time)
      # If not equal, then stop 
      if (lingest != lingesttimes){
        stop("The times of ingestion rate change should be equal to the ingestion time vector")
      }else{
        if(exp_type == "pharmacokinetics"){
          # For pharmacokinetic studies, add the dose directly to the stomach compartment
          events <- list(data = data.frame(var = c("AST"),  time = ingestion_time, 
                                           value = ingestion, method = c("add")))
        }else{
          # For continuous exposure studies, set the ingestion rate
          events <- list(data = data.frame(var = c("ingestion"),  time = ingestion_time, 
                                           value = ingestion, method = c("rep")))
        }
      }
    }
    
    
    
    
    return(events)
  })
}


#==================
#4. Custom function 
#==================
#'  
#' @export
#'  
.custom.func <- function(){
  return()
}

#==============
#5. ODEs System
#==============
#'  
#' @export
#'  
.ode.func.chou <- function(time, inits, params, custom.func){
  with(as.list(c(inits,params)),{
    
    CR = AR/VR #concentration in rest of body (ug/L)
    CVR = CR/PR	#concentration in venous plasma leaving the rest of the body (ug/L)
    CKb = AKb/VKb	#concentration in kidney blodd (ug/L) 
    CVK = CKb /PK	#concentration in venous plasma leaving kidney (ug/L)
    CK = CVK*PK
    CPTC = APTC/VPTC	#concentration in PTC (ug/L)
    Cfil = Afil/Vfil	#concentration in filtrate (ug/L)
    CL = AL/VL	#concentration in the liver (ug/L)
    CLiver = AL/ML #	concentration in the liver (ug/g)
    CVL = CL/PL	#concentration in the venous plasma leaving the liver (ug/L)
    CA =  Aplas/VPlas	#concentration of total PFOA in plasma (ug/L)
    CA_free = CA *	Free	#free concentration in plasma (ug/L)
    Curine = Aurine/kvoid
    
    # Rest of Body (Tis)
    dAR = QR*(CA-CVR)*Free	#rate of change in rest of body (ug/time_scale)
    
    #Kidney 
    #Kidney plasma (Kb)
    dAdif = kdif*(CKb - CPTC)	#rate of diffusion from into the PTC (ug/time_scale)
    dA_baso = (Vmax_baso*CKb)/(Km_baso + CKb)	
    dAKb = QK*(CA-CVK)*Free - CA*GFR*Free - dAdif - dA_baso #rate of change in kidney plasma (ug/time_scale).
    dACl = CA*GFR*Free	#rate of clearance via glormerular filtration (ug/time_scale)
    
    #Proximal Tubule Cells (PTC)
    dAefflux = kefflux*APTC
    dA_apical = (Vmax_apical*Cfil)/(Km_apical + Cfil)
    dAPTC =  dAdif + dA_apical + dA_baso - dAefflux #rate of change in PTC(ug/time_scale)
    
    #Filtrate (Fil)
    dAfil = CA*GFR*Free - dA_apical - Afil*kurine	#rate of change in filtrate (ug/time_scale)
    
    #Urinary elimination 
    dAurine = kurine*Afil	#rate of change in urine (ug/time_scale)
    
    #GI Tract (Absorption site of oral dose)
    #Stomach
    dAST=  ingestion  - k0*AST - GE*AST	#rate of change in the stomach (ug/time_scale)
    dAabsST = k0*AST	#rate of absorption in the stomach (ug/time_scale)
    
    #Small Intestine
    dASI = GE*AST - kabs*ASI - kunabs*ASI	#rate of change in the small intestine (ug/time_scale)
    dAabsSI = kabs*ASI	#rate of absorption inthe small intestine (ug/time_scale)
    
    total_oral_uptake = AabsSI + AabsST	#total oral uptake in the GI tract (ug) 
    
    #Feces compartment
    dAfeces = kbile*AL + kunabs*ASI #rate of change in the feces compartment (ug/time_scale)
    
    #Liver
    dAL = QL*(CA-CVL)*Free - kbile*AL + kabs*ASI + k0*AST #rate of change in the liver (ug/time_scale)
    dAbile = kbile*AL
    amount_per_gram_liver = CLiver	#amount of PFOS in liver per gram liver (ug/g)
    
    #Plasma compartment
    dAplas = (QR*CVR*Free) + (QK*CVK*Free) + (QL*CVL*Free) - 
      (QC*CA*Free) + dAefflux  #rate of change in the plasma (ug/time_scale) 
    
    dingestion = 0
    
    #Mass Balance Check
    Atissue = Aplas + AR + AKb + Afil + APTC + AL + AST + ASI 	#sum of mass in all compartments (ug)
    Aloss = Aurine + Afeces #sum of mass lost through urinary and fecal excretion (ug)
    Atotal = Atissue + Aloss 	#total mass; should equal total dose
    
    list(c("dAR" = dAR, "dAdif" = dAdif, "dA_baso" = dA_baso, "dAKb" = dAKb,
           "dACl" = dACl, "dAefflux" = dAefflux,
           "dA_apical" = dA_apical, "dAPTC" = dAPTC, "dAfil" = dAfil,
           "dAurine" = dAurine, "dAST" =dAST,
           "dAabsST" = dAabsST, "dASI" = dASI, "dAabsSI" = dAabsSI, "dAfeces" = dAfeces, 
           "dAL" = dAL, "dAbile" = dAbile, "dAplas" = dAplas,
           "dingestion" = dingestion), 
         "total_oral_uptake" = total_oral_uptake, "amount_per_gram_liver" = amount_per_gram_liver,
         "Atissue" = Atissue, "Aloss" = Aloss, "Atotal" = Atotal, "CR" =CR, "CVR" = CVR, "CKb" = CKb, 
         "CVK" = CVK, "CPTC" = CPTC,
         "Cfil" = Cfil, "CL" = CL, "CVL" = CVL, "CA_free" = CA_free, "CA" = CA,
         "Cserum" = CA, "Cliver" = CL )
    
  })
}


#############
# worley model
############
#'  
#' @export
#'  
.create.params.worley  <- function(user_input){
  with( as.list(user_input),{
    # User input: BW(kg)
    
    #Initial time: hours
    if  (missing(time_scale) || is.na(time_scale)){
      time_scale <- 1/24
    }else if (time_scale == "minutes"){
      time_scale <- 60
    }else if (time_scale == "hours"){
      time_scale <- 1
    }else if (time_scale == "days"){
      time_scale <- 1/24
    }else if (time_scale == "weeks"){
      time_scale <- (1/24)/7
    }else if (time_scale == "months"){
      time_scale <- ((1/24)/30)
    }else if (time_scale == "years"){
      time_scale <- ((1/24)/365)
    }
    inv_time_scale <- 1/time_scale
    
    #Cardiac Output and plasmaflow (as fraction of cardiac output)
    QCC = 12.5*inv_time_scale #cardiac output in L/time_scale/kg^0.75; Brown 1997		 
    QLC = 0.25 #fraction plasma flow to liver; Brown 1997	
    QKC = 0.175 #fraction plasma flow to kidney; Brown 1997.
    Htc = 0.44 #hematocrit for the rat; Davies 1993
    
    #Tissue Volumes 
    VplasC = 0.0428 #fraction vol. of plasma (L/kg BW); Davies 1993
    VLC = 0.026 #fraction vol. of liver (L/kg BW); Brown 1997
    VKC = 0.004 #fraction vol. of kidney (L/kg BW); Brown 1997
    VfilC = 4e-4	#fraction vol. of filtrate (L/kg BW)
    VPTCC = 1.35e-4 #vol. of proximal tubule cells (L/g kidney) (60 million PTC cells/gram kidney, 1 PTC = 2250 um3)
    
    #Chemical Specific Parameters
    MW = 414.07	#PFOA molecular mass (g/mol)
    
    Free = 0.02#0.006 #free fraction in plasma (male)
    
    #Kidney Transport Parameters
    Vmax_baso_invitro = 439.2 #Vmax of basolateral transporter (pmol/mg protein/min); averaged in vitro value of OAT1 and OAT3 from Nakagawa, 2007
    Km_baso = 20100 #Km of basolateral transporter (ug/L) Average of OAT1 and OAT3 from Nakagawa et. al, 2007
    Vmax_apical_invitro = 37400 #Vmax of apical transporter (pmol/mg protein/min); invitro value for OAT4 from Yang et al, 2010
    Km_apical = 77500#Km of apical transporter (ug/L), in vitro value for OAT4 and URAT1 from Yang et al, 2010.
    RAFbaso = 1	#relative activity factor, basolateral transporters (male) (fit to data)	
    RAFapi = 0.0007	#relative activity factor, apical transporters (male) (fit to data)	
    protein = 2.0e-6	#amount of protein in proximal tubule cells (mg protein/proximal tubule cell)
    GFRC = 24.19*inv_time_scale	#glomerular filtration rate (L/time_scale/kg kidney) (male); Corley, 2005
    
    #Partition Coefficients (from rat tissue data, Kudo et al, 2007)
    PL = 1.03 #liver:plasma
    PK = 1.17 #kidney:plasma
    PR = 0.11 #rest of body:plasma
    
    #rate constants
    kdif = 0.001*inv_time_scale	#diffusion rate from proximal tubule cells (L/time_scale)
    kabsc = 2.12*inv_time_scale	#rate of absorption of chemical from small intestine to liver (1/(time_scale*BW^-0.25))(fit to data)
    kunabsc = 7.06e-5*inv_time_scale	#rate of unabsorbed dose to appear in feces (1/(time_scale*BW^-0.25))(fit to data)
    GEC = 3.5*inv_time_scale#gastric emptying time (1/(time_scale*BW^-0.25)); from Yang, 2013
    k0C = 1.0*inv_time_scale	#rate of uptake from the stomach into the liver (1/(time_scale*BW^-0.25)) (fit to data)
    
    keffluxc =0.1*inv_time_scale #rate of clearance of PFOA from proximal tubule cells into plasma (1/(time_scale*BW^-0.25))
    kbilec = 0.0001*inv_time_scale #biliary elimination rate ((male); liver to feces storage (1/(time_scale*BW^-0.25)) (fit to data)
    kurinec = 0.063*inv_time_scale #rate of urine elimination from urine storage (male) (1/(time_scale*BW^-0.25))(fit to data)
    kvoid = 0.06974*inv_time_scale  #daily urine volume rate (L/time_scale); Van Haarst, 2004                                                   
    
    #Scaled Parameters
    #Cardiac output and plasma flows
    QC = QCC*(BW^0.75)*(1-Htc)	#cardiac output in L/time_scale; adjusted for plasma
    QK = (QKC*QC)	#plasma flow to kidney (L/time_scale)
    QL = (QLC*QC)	#plasma flow to liver (L/time_scale)
    QR = QC - QK - QL 	#plasma flow to rest of body (L/time_scale)
    QBal = QC - (QK + QL + QR) #Balance check of plasma flows; should equal zero
    
    #Tissue Volumes
    
    VPlas = VplasC*BW 	#volume of plasma (L) 
    VK = VKC*BW 	#volume of kidney (L)
    MK = VK*1.0*1000	#mass of the kidney (g)
    VKb = VK*0.16	#volume of blood in the kidney (L); fraction blood volume of kidney (0.16) from Brown, 1997
    Vfil = VfilC*BW	#volume of filtrate (L)
    VL = VLC*BW	#volume of liver (L)
    ML = VL*1.05*1000	#mass of the liver (g)
    
    #Kidney Parameters
    
    PTC = VKC*1000*6e7	#number of PTC (cells/kg BW) (based on 60 million PTC/gram kidney, assuming density of 1 kg/L)
    VPTC = VK*1000*VPTCC	#volume of proximal tubule cells (L)	
    MPTC = VPTC*1000 #mass of the proximal tubule cells (g) (assuming density 1 kg/L)	
    VR = (0.93*BW) - VPlas - VPTC - Vfil - VL	#volume of remaining tissue (L); 
    VBal = (0.93*BW) - (VR + VL + VPTC + Vfil + VPlas)	#Balance check of tissue volumes; should equal zero 
    
    Vmax_basoC = (Vmax_baso_invitro*RAFbaso*PTC*protein*60*(MW/1e12)*1e6)*inv_time_scale#Vmax of basolateral transporters (ug/time_scale/kg BW)
    Vmax_apicalC = (Vmax_apical_invitro*RAFapi*PTC*protein*60*(MW/1e12)*1e6)*inv_time_scale #Vmax of basolateral transporters (ug/time_scale/kg BW)
    Vmax_baso = Vmax_basoC*BW^0.75	#(ug/time_scale)
    Vmax_apical = Vmax_apicalC*BW^0.75	#(ug/time_scale)
    kbile = kbilec*BW^(-0.25)	#biliary elimination; liver to feces storage (/time_scale)
    kurine = kurinec*BW^(-0.25)	#urinary elimination, from filtrate (/time_scale)
    kefflux = keffluxc*BW^(-0.25)	#efflux clearance rate, from PTC to plasma (/time_scale)
    GFR = GFRC*VK	#glomerular filtration rate, scaled to mass of kidney(in kg)(L/time_scale)
    
    #GI Tract Parameters
    kabs = kabsc*BW^(-0.25)	#rate of absorption of chemical from small intestine to liver (/time_scale)
    kunabs = kunabsc*BW^(-0.25)	#rate of unabsorbed dose to appear in feces (/time_scale)
    GE = GEC*BW^(-0.25)	#gastric emptying time (/time_scale)
    k0 = k0C*BW^(-0.25) 	#rate of uptake from the stomach into the liver (/time_scale)
    
    water_consumption <- 1.36# L/time_scale
    
    return(list( "Free" = Free, "QC" = QC, "QK" = QK, "QL" = QL, "QR" = QR, 
                 "VPlas" = VPlas,
                 "VKb" = VKb, "Vfil" = Vfil, "VL" = VL, "VR" = VR, "ML" = ML,
                 "VPTC" = VPTC, "Vmax_baso" = Vmax_baso, "Vmax_apical" = Vmax_apical,
                 'kdif' = kdif, "Km_baso" = Km_baso, "Km_apical" = Km_apical,
                 "kbile" = kbile, "kurine" = kurine, "kefflux" = kefflux,
                 "GFR" = GFR, "kabs" = kabs, "kunabs" = kunabs, "GE" = GE, "k0" = k0,
                 "PL" = PL, "PK" = PK, "PR" = PR, "kvoid" = kvoid,
                 "ingestion" = ingestion, "ingestion_time" = ingestion_time,
                 "admin_dose" = admin_dose, "admin_time" = admin_time,
                 "admin_type" = admin_type, "exp_type" = exp_type
    ))
    
  })
}

#===============================================
#2. Function to create initial values for ODEs 
#===============================================
#'  
#' @export
#'  
.create.inits.worley <- function(parameters){
  with( as.list(parameters),{
    "AR" = 0; "Adif" = 0; "A_baso" = 0; "AKb" = 0;
    "ACl" = 0; "Aefflux" = 0;
    "A_apical" = 0; "APTC" = 0; "Afil" = 0;
    "Aurine" = 0; "AST" = 0;
    "AabsST" = 0; "ASI" = 0; "AabsSI" = 0; "Afeces" = 0;
    "AL" = 0; "Abile" = 0; "Aplas" = 0;
    "ingestion" = 0;
    
    return(c("AR" = AR, "Adif" = Adif, "A_baso" = A_baso, "AKb" = AKb,
             "ACl" = ACl, "Aefflux" = Aefflux,
             "A_apical" = A_apical, "APTC" = APTC, "Afil" = Afil,
             "Aurine" = Aurine, "AST" = AST,
             "AabsST" = AabsST, "ASI" = ASI, "AabsSI" = AabsSI, "Afeces" = Afeces, 
             "AL" = AL, "Abile" = Abile, "Aplas" = Aplas,
             "ingestion" = ingestion))
  })
}

#===================
#3. Events function
#===================
#' 
#' @export
#' 
.create.events.worley <- function(parameters){
  with(as.list(parameters), {
    if (tolower(admin_type) == "iv"){
      # Calculate number of administrated doses and corresponding administration time for IV
      ldose <- length(admin_dose)
      ltimes <- length(admin_time)
      # If not equal, then stop 
      if (ltimes != ldose){
        stop("The times of administration should be equal in number to the doses")
      }else{
        events <- list(data = rbind(data.frame(var = c("Aplas"),  time = admin_time, 
                                               value = admin_dose, method = c("add")) ))
      }
    }else{
      lingest <- length(ingestion)
      lingesttimes <- length(ingestion_time)
      # If not equal, then stop 
      if (lingest != lingesttimes){
        stop("The times of ingestion rate change should be equal to the ingestion time vector")
      }else{
        if(exp_type == "pharmacokinetics"){
          # For pharmacokinetic studies, add the dose directly to the stomach compartment
          events <- list(data = data.frame(var = c("AST"),  time = ingestion_time, 
                                           value = ingestion, method = c("add")))
        }else{
          # For continuous exposure studies, set the ingestion rate
          events <- list(data = data.frame(var = c("ingestion"),  time = ingestion_time, 
                                           value = ingestion, method = c("rep")))
        }
      }
    }
    
    return(events)
  })
}

#==================
#4. Custom function 
#==================
#' 
#' @export
#'  
.custom.func <- function(){
  return()
}

#==============
#5. ODEs System
#==============
#'  
#' @export
#' 
.ode.func.worley <- function(time, inits, params, custom.func){
  with(as.list(c(inits,params)),{
    
    CR = AR/VR #concentration in rest of body (ug/L)
    CVR = CR/PR	#concentration in venous plasma leaving the rest of the body (ug/L)
    CKb = AKb/VKb	#concentration in kidney blodd (ug/L) 
    CVK = CKb #/PK	#concentration in venous plasma leaving kidney (ug/L)
    CPTC = APTC/VPTC	#concentration in PTC (ug/L)
    Cfil = Afil/Vfil	#concentration in filtrate (ug/L)
    CL = AL/VL	#concentration in the liver (ug/L)
    CLiver = AL/ML #	concentration in the liver (ug/g)
    CVL = CL/PL	#concentration in the venous plasma leaving the liver (ug/L)
    CA =  Aplas/VPlas	#concentration of total PFOA in plasma (ug/L)
    CA_free = CA *	Free	#free concentration in plasma (ug/L)
    Curine = Aurine/kvoid
    
    # Rest of Body (Tis)
    dAR = QR*(CA-CVR)*Free	#rate of change in rest of body (ug/time_scale)
    
    #Kidney 
    #Kidney plasma (Kb)
    dAdif = kdif*(CKb - CPTC)	#rate of diffusion from into the PTC (ug/time_scale)
    dA_baso = (Vmax_baso*CKb)/(Km_baso + CKb)	
    dAKb = QK*(CA-CVK)*Free - CA*GFR*Free - dAdif - dA_baso #rate of change in kidney plasma (ug/time_scale).
    dACl = CA*GFR*Free	#rate of clearance via glormerular filtration (ug/time_scale)
    
    #Proximal Tubule Cells (PTC)
    dAefflux = kefflux*APTC
    dA_apical = (Vmax_apical*Cfil)/(Km_apical + Cfil)
    dAPTC =  dAdif + dA_apical + dA_baso - dAefflux #rate of change in PTC(ug/time_scale)
    
    #Filtrate (Fil)
    dAfil = CA*GFR*Free - dA_apical - Afil*kurine	#rate of change in filtrate (ug/time_scale)
    
    #Urinary elimination 
    dAurine = kurine*Afil	#rate of change in urine (ug/time_scale)
    
    #GI Tract (Absorption site of oral dose)
    #Stomach
    dAST=  ingestion - k0*AST - GE*AST	#rate of change in the stomach (ug/time_scale)
    dAabsST = k0*AST	#rate of absorption in the stomach (ug/time_scale)
    
    #Small Intestine
    dASI = GE*AST - kabs*ASI - kunabs*ASI	#rate of change in the small intestine (ug/time_scale)
    dAabsSI = kabs*ASI	#rate of absorption inthe small intestine (ug/time_scale)
    
    total_oral_uptake = AabsSI + AabsST	#total oral uptake in the GI tract (ug) 
    
    #Feces compartment
    dAfeces = kbile*AL + kunabs*ASI #rate of change in the feces compartment (ug/time_scale)
    
    #Liver
    dAL = QL*(CA-CVL)*Free - kbile*AL + kabs*ASI + k0*AST #rate of change in the liver (ug/time_scale)
    dAbile = kbile*AL
    amount_per_gram_liver = CLiver	#amount of PFOA in liver per gram liver (ug/g)
    
    #Plasma compartment
    dAplas = (QR*CVR*Free) + (QK*CVK*Free) + (QL*CVL*Free) - 
      (QC*CA*Free) + dAefflux  #rate of change in the plasma (ug/time_scale) 
    
    dingestion = 0
    
    #Mass Balance Check
    Atissue = Aplas + AR + AKb + Afil + APTC + AL + AST + ASI 	#sum of mass in all compartments (ug)
    Aloss = Aurine + Afeces #sum of mass lost through urinary and fecal excretion (ug)
    Atotal = Atissue + Aloss 	#total mass; should equal total dose
    
    list(c("dAR" = dAR, "dAdif" = dAdif, "dA_baso" = dA_baso, "dAKb" = dAKb,
           "dACl" = dACl, "dAefflux" = dAefflux,
           "dA_apical" = dA_apical, "dAPTC" = dAPTC, "dAfil" = dAfil,
           "dAurine" = dAurine, "dAST" =dAST,
           "dAabsST" = dAabsST, "dASI" = dASI, "dAabsSI" = dAabsSI, "dAfeces" = dAfeces, 
           "dAL" = dAL, "dAbile" = dAbile, "dAplas" = dAplas,
           "dingestion" = dingestion), 
         "total_oral_uptake" = total_oral_uptake, "amount_per_gram_liver" = amount_per_gram_liver,
         "Atissue" = Atissue, "Aloss" = Aloss, "Atotal" = Atotal, "CR" =CR, "CVR" = CVR, "CKb" = CKb, 
         "CVK" = CVK, "CPTC" = CPTC,
         "Cfil" = Cfil, "CL" = CL, "CVL" = CVL, "CA_free" = CA_free, "CA" = CA,
         "Cserum" = CA, "Cliver" = CL)
    
  })
}


#################
# fabrega model
#################
#' 
#' @export
#'  
.create.params.fabrega <- function(user_input){
  with(as.list(user_input),{
    
    #Initial time: hours
    if  (missing(time_scale) || is.na(time_scale)){
      time_scale <- 1/24
    }else if (time_scale == "minutes"){
      time_scale <- 60
    }else if (time_scale == "hours"){
      time_scale <- 1
    }else if (time_scale == "days"){
      time_scale <- 1/24
    }else if (time_scale == "weeks"){
      time_scale <- (1/24)/7
    }else if (time_scale == "months"){
      time_scale <- ((1/24)/30)
    }else if (time_scale == "years"){
      time_scale <- ((1/24)/365)
    }
    inv_time_scale <- 1/time_scale
    
    # Physiological parameters (from Brown, et al)
    # fractional bloo flows to tissues
    QCC = 12.5		  # Cardiac plasma output (L/h/kg^0.75)
    QFC = 0.052		  # Fraction cardiac output going to fat
    QLC = 0.19 #0.25 from loccisano 2011 		  # Fraction cariac output going to liver
    QKC = 0.175		  # Fraction cardiac output going to kiney
    #QFilC = 0.035		# Fraction cardiac output to the filtrate compartment (20% of kiney plasma flow)
    QGC = 0.181		  # Fraction cardiac output going to gut
    QLuC = 0.034    # Fraction cardiac output going to lungs
    QBC = 0.117    # Fraction cardiac output going to brain
    
    
    #fractional tissue volumes
    VLC = 0.023		  # Fraction liver volume
    VFC = 0.02 #0.214		  # Fraction fat volume
    VKC = 0.004		  # Fraction kidney volume
    VFilC = 0.0004	# Fraction filtrate compartment volume (10% of kidney volume)
    VGC = 0.0171		# Fraction gut volume
    VPlasC = 0.0428	# Fraction plasma volume
    VLuC = 0.014	# Fraction lungs volume
    VBC = 0.021	# Fraction lungs volume
    
    # Scaling parameters
    QC = QCC*(BW^0.75)*inv_time_scale	#Cardiac output (L/time_scale)
    Htc = 0.44      #hematocrit
    QCP = QC*(1-Htc)	# Plasma flow
    QL = QLC*QCP			# Plasma flow to liver (L/time_scale)
    QF = QFC*QCP			# Plasma flow to fat (L/time_scale)
    QK = QKC*QCP	    # Plasma flow to kiney (L/time_scale)
    QFil = 0.2*QK   	# Plasma flow to filtrate compartment (L/time_scale)# 20% of QK
    QG = QGC*QCP	    # Plasma flow to gut (L/time_scale)
    QLu = QLuC*QCP	  # Plasma flow to lungs (L/time_scale)
    QB = QBC*QCP	    # Plasma flow to brain (L/time_scale)
    QR = QCP - QL - QF - QK - QFil - QG - QLu - QB	 # Plasma flow to rest of the boy (L/time_scale)
    
    Qbal = QCP - (QL+QF+QK+QFil+QG+QR+QLu+QB)        # balance check 
    
    VL = VLC*BW			    # Liver volume (L)
    VF = VFC*BW			    # Fat volume (L)
    VK = VKC*BW			    # Kiney volume (L)
    VFil = VFilC*BW	    # Fitrate compartment volume (L)
    VG = VGC*BW			    # Gut volume (L)
    VPlas = VPlasC*BW		# Plasma volume (L)
    VLu = VLuC*BW			  # Lungs volume (L)
    VB = VBC*BW			    # Brain volume (L)
    VR = 1*BW - VL - VF - VK - VFil - VG -VLu -VB - VPlas		# Rest of the boy volume (L) # loccisano 2011 uses 0.84*BW
    
    Vbal = (1*BW)-(VL+VF+VK+VFil+VG+VPlas+VR+VLu+VB)         # Balance check
    
    
    if(chemical == 'PFOA'){
      Tm = 147.4*inv_time_scale #ug/time_scale
      Kt = 0.116 #ug/L
      Free = 0.03 # fabrega (2014) Table 1
      PL = 1.03 # Partition Coefficient for Liver: fabrega (2014) Table 1
      PF = 0.467; # Partition Coefficient for Fat: fabrega (2014) Table 1
      PB = 0.17; # Partition Coefficient for Brain: fabrega (2014) Table 1
      PLu = 1.27; # Partition Coefficient for Lungs: fabrega (2014) Table 1
      PK = 1.17 # Partition Coefficient for Kidney: fabrega (2014) Table 1
      PG = 0.05 # Partition Coefficient for Gut: loccisano (2011) Table 1
      PR = 0.12 # Partition Coefficient for Rest of body: loccisano (2011) Table 1
      kurinec = 3e-04	#urinary elimination rate constant  (/h/kg^-0.25); 
      kurine = kurinec*(BW^-0.25)*inv_time_scale # Elimination rate (1/time_scale)
    }else if(chemical == 'PFOS'){
      Tm = 86*inv_time_scale #ug/time_scale
      Kt = 0.0176 #ug/L
      Free = 0.03 # fabrega (2014) Table 1
      PL = 2.67 # Partition Coefficient for Liver: fabrega (2014) Table 1
      PF = 0.33 # Partition Coefficient for Fat: fabrega (2014) Table 1
      PB = 0.255 # Partition Coefficient for Brain: fabrega (2014) Table 1
      PLu = 0.155 # Partition Coefficient for Lungs: fabrega (2014) Table 1
      PK = 1.26 # Partition Coefficient for Kidney: fabrega (2014) Table 1
      PG = 0.57 # Partition Coefficient for Gut: loccisano (2011) Table 1
      PR = 0.2 # Partition Coefficient for Rest of body: loccisano (2011) Table 1
      kurinec = 1e-3	#urinary elimination rate constant  (/h/kg^-0.25); estimated from Harada, 
      kurine =kurinec*BW^(-0.25)*inv_time_scale # Elimination rate (1/time_scale)
    }
    return(list('QC'=QC, 'QCP'=QCP, 'QL'=QL, 'QF'=QF, 'QK'=QK, 
                'QFil'=QFil, 'QG'=QG, 'QLu'=QLu, 'QB'=QB, 'QR'=QR,
                'VPlas'=VPlas, 'VL'=VL, 'VF'=VF, 'VK'=VK, 
                'VFil'=VFil, 'VG'=VG, 'VLu'=VLu, 'VB'=VB, 'VR'=VR,
                'PL'=PL, 'PF'=PF, 'PB'=PB, 'PLu'=PLu, 'PK'=PK, 
                'PG'=PG, 'PR'=PR,
                'Tm'=Tm, 'Kt'=Kt, 'Free'=Free, 'kurine'=kurine, 
                "ingestion" = ingestion, "ingestion_time" = ingestion_time,
                "admin_dose" = admin_dose, "admin_time" = admin_time,
                "admin_type" = admin_type, "exp_type" = exp_type))
  })
}

#'  
#' @export
#' 
.create.inits.fabrega <- function(parameters){
  with(as.list(parameters),{
    
    APlas<-0; AG<-0; AL<-0; AF<-0; ALu<-0; AB<-0
    AK<-0; AFil<-0; AStore<-0; AUrine<-0
    AR<-0; ingestion<-0; 
    
    return(c("APlas"=APlas, "AG"=AG, "AL"=AL, "AF"=AF, "ALu"=ALu, "AB"=AB,
             "AK"=AK, "AFil"=AFil, "AStore"=AStore, "AUrine"=AUrine,
             "AR"=AR, 'ingestion'=ingestion
    ))
  })
}

#'  
#' @export
.create.events.fabrega <- function(parameters){
  with(as.list(parameters), {
    if (tolower(admin_type) == "iv"){
      # Calculate number of administrated doses and corresponding administration time for IV
      ldose <- length(admin_dose)
      ltimes <- length(admin_time)
      # If not equal, then stop 
      if (ltimes != ldose){
        stop("The times of administration should be equal in number to the doses")
      }else{
        events <- list(data = rbind(data.frame(var = c("APlas"),  time = admin_time, 
                                               value = admin_dose, method = c("add")) ))
      }
    }else if(admin_type == "oral"){
      lingest <- length(ingestion)
      lingesttimes <- length(ingestion_time)
      # If not equal, then stop 
      if (lingest != lingesttimes){
        stop("The times of ingestion rate change should be equal to the ingestion time vector")
      }else{
        if(exp_type == "pharmacokinetics"){
          # For pharmacokinetic studies, add the dose directly to the gut compartment
          events <- list(data = data.frame(var = c("AG"),  time = ingestion_time, 
                                           value = ingestion, method = c("add")))
        }else if(exp_type == "biomonitoring"){
          # For continuous exposure studies, set the ingestion rate
          events <- list(data = data.frame(var = c("ingestion"),  time = ingestion_time, 
                                           value = ingestion, method = c("rep")))
        }else{
          events <- list(data = data.frame(var = c("ingestion"),  time = ingestion_time, 
                                           value = ingestion, method = c("rep")))
        }
      }
    }
    
    return(events)
  })
}

#' 
#' @export
#'  
.custom.func <- function(){
  return()
}

#'  
#' @export
#' 
.ode.func.fabrega <- function(time, inits, params, custom.func){
  with(as.list(c(inits,params)),{
    
    # Units
    # C_i: Concentration in tissue i (ug/L) 
    # ingestion: hourly ingestion of PFASs (ug/h)
    
    # Concentrations (ng/g)
    CPlas <- APlas/VPlas # Concentration in plasma
    CG <- AG/VG # Concentration in Gut
    CL <- AL/VL # Concentration in Liver
    CF <- AF/VF # Concentration in Fat
    CLu <- ALu/VLu # Concentration in Lungs
    CB <- AB/VB # Concentration in Brain
    CK <- AK/VK # Concentration in Kidney
    CFil <- AFil/VFil # Concentration in Filtration compartment
    CR <- AR/VR  # Concentration in Rest of the body compartment
    
    # Plasma compartment (ng)
    dAPlas <- QF*Free*CF/PF + (QL+QG)*Free*CL/PL + QR*Free*CR/PR + QK*Free*CK/PK + 
      QB*Free*CB/PB + QLu*Free*CLu/PLu - QCP*Free*CPlas
    
    # Gut compartment
    dAG <- QG*Free*(CPlas - CG/PG) + ingestion
    
    # Liver compartment
    dAL <- QL*Free*CPlas + QG*Free*CG/PG - (QL+QG)*Free*CL/PL
    
    # Fat compartment
    dAF <- QF*Free*(CPlas - CF/PF)
    
    # Lungs Compartment
    dALu <- QLu*Free*(CPlas - CLu/PLu)
    
    # Brain Compartment
    dAB <- QB*Free*(CPlas - CB/PB)
    
    # Kidney compartment
    dAK <- QK*Free*(CPlas - CK/PK) + (Tm*CFil)/(Kt+CFil)
    
    # Filtrate compartment
    dAFil = QFil*(Free*CPlas - CFil) - (Tm*CFil)/(Kt+CFil)
    
    # Storage compartment for urine
    dAStore <- QFil*CFil - kurine*AStore
    
    # Amount excrete via urine
    dAUrine <- kurine*AStore
    
    # Rest of the body
    dAR <- QR*Free*(CPlas - CR/PR)
    
    # PFAS concentration
    dingestion <- 0
    
    #Total
    Atotal <- APlas+AG+AL+AF+ALu+AB+AK+AFil+AStore+AUrine+AR
    
    return(list(c("dAPlas"=dAPlas, "dAG"=dAG, "dAL"=dAL, "dAF"=dAF, "dALu"=dALu, 
                  "dAB"=dAB, "dAK"=dAK, "dAFil"=dAFil, "dAStore"=dAStore, "dAUrine"=dAUrine,
                  "dAR"=dAR, 'dingestion'=dingestion),
                "CPlas"=CPlas, "CG"=CG, "CL"=CL, "CF"=CF, "CLu"=CLu, "CB"=CB,
                "CK"=CK, "CFil"=CFil, "CR"=CR,   "Cserum" = CPlas, "Cliver" = CL, "Atotal" = Atotal) ) 
  })
}



#################
# loccisano model
#################
#'  
#' @export
#' 
.create.params.loccisano <- function(user_input){
  with(as.list(user_input),{
    #Initial time: hours
    if  (missing(time_scale) || is.na(time_scale)){
      time_scale <- 1/24
    }else if (time_scale == "minutes"){
      time_scale <- 60
    }else if (time_scale == "hours"){
      time_scale <- 1
    }else if (time_scale == "days"){
      time_scale <- 1/24
    }else if (time_scale == "weeks"){
      time_scale <- (1/24)/7
    }else if (time_scale == "months"){
      time_scale <- ((1/24)/30)
    }else if (time_scale == "years"){
      time_scale <- ((1/24)/365)
    }
    inv_time_scale <- 1/time_scale
    
    # Physiological parameters (from Brown, et al 1997)
    #fractional plasma flows
    QCC = 12.5 		# Cardiac plasma output (L/h/kg^0.75)
    QFC = 0.052		# Fraction cardiac output going to fat
    QLC = 0.25 		# Fraction cardiac output going to liver
    QKC = 0.175		# Fraction cardiac output going to kidney
    #QfilC = 0.035		# Fraction cardiac output to the filtrate compartment (20% of kidney plasma flow)
    QSkC = 0.058	# Fraction cardiac output going to skin
    QGC = 0.181		# Fraction cardiac output going to gut
    
    #fractional tissue volumes
    VLC = 0.026		# Fraction liver volume
    VFC = 0.214		# Fraction fat volume
    VKC = 0.004		# Fraction kidney volume
    VfilC = 0.0004	# Fraction filtrate compartment volume (10% of kidney volume)
    VGC = 0.0171		# Fraction gut volume
    VPlasC = 0.0428	# Fraction plasma volume (58% of blood)
    Htc = 0.44    # hematocrit
    
    # for dermal exposure
    # Dermal exposure
    Dermconc <- 0.0		# Dermal concentration (mg/mL)
    Dermvol <- 0.0		  # Dermal exposure volume (mL)
    Dermdose <- Dermconc*Dermvol*1000  # (ug)
    Skinarea = 5		#Exposed area on skin (cm^2)
    SkinTarea = 9.1*((BW*1000)**0.666)	  # Total area of skin (cm^2)
    Skinthickness = 0.1	                  # Skin thickness (cm)
    
    # Scaling parameters
    QC = inv_time_scale*QCC*BW**0.75	# Cardiac output (L/time_scale)
    QCP = QC*(1-Htc)	# adjust for plasma flow
    QL = QLC*QCP			# Plasma flow to liver (L/time_scale)
    QF = QFC*QCP			# Plasma flow to fat (L/time_scale)
    QK = QKC*QCP	    # Plasma flow to kidney (L/time_scale)
    Qfil = 0.2*QK		  # Plasma flow to filtrate compartment (L/time_scale)# 20% of QK
    QG = QGC*QCP		  # Plasma flow to gut (L/time_scale)
    QSk <- ifelse(Dermconc > 0, QSkC*QCP*(Skinarea/SkinTarea), 0.0) # plasma flow to skin
    #QSk <- QSkC*QCP*(Skinarea/SkinTarea) # plasma flow to skin
    QR = QCP - QL - QF - QK - Qfil - QG - QSk	# Plasma flow to rest of the body (L/time_scale)
    
    Qbal = QCP - (QL+QF+QK+Qfil+QG+QSk+QR)       # balance check--better be 0
    
    VL = VLC*BW			# Liver volume (L)
    VF = VFC*BW			# Fat volume (L)
    VK = VKC*BW			# Kidney volume (L)
    Vfil = VfilC*BW			# Fitrate compartment volume (L)
    VG = VGC*BW			# Gut volume (L)
    VPlas = VPlasC*BW		# Plasma volume (L)
    VSk = (Skinarea*Skinthickness)/1000	                                    # Skin volume (L)
    VR = 0.84*BW - VL - VF - VK - Vfil - VG - VPlas - VSk	          # Rest of the body volume (L)
    Vbal = (0.84*BW)-(VL+VF+VK+Vfil+VG+VPlas+VSk+VR)               # Balance check--better be 0
    
    if(chemical == 'PFOA'){
      # Chemical-specific parameters (PFOA)
      Tmc = inv_time_scale*6			# Maximum resorption rate (ug/time_scale/kg^(0.75))
      Kt = 0.055		# Resorption affinity (ug/L)
      Free = 0.02		# Free fraction of PFOA in plasma# same as monkey
      PL = 2.2			# Liver/plasma partition coefficient
      PF = 0.04			# Fat/plasma partition coefficient
      PK = 1.05			# Kidney/plasma partition coefficient
      PSk = 0.1			# Skin/plasma partition coefficient
      PR = 0.12			# Rest of the body/plasma partition coefficient
      PG = 0.05     # Gut/plasma plasma coeff. 
      kurinec =inv_time_scale* 0.0003		# Elimination rate (1/time_scale)# estimated from data of Harada, et al 2005
    } else if(chemical == 'PFOS'){
      # Chemical-specific parameters (PFOS)
      Tmc = inv_time_scale*3.5			# Maximum resorption rate (ug/time_scale/kg^(0.75))
      Kt = 0.023		# Resorption affinity (ug/L)
      Free = 0.025	# Free fraction of PFOS in plasma
      PL = 3.72			# Liver/plasma partition coefficient
      PF = 0.14			# Fat/plasma partition coefficient
      PK = 0.8			# Kidney/plasma partition coefficient
      PSk = 0.29		# Skin/plasma partition coefficient
      PR = 0.2			# Rest of the body/plasma partition coefficient
      PG = 0.57     # Gut/plasma partition coeff. 
      kurinec =inv_time_scale* 0.001		# urinary elimination rate constant  (/h/kg^-0.25)# estimated from Harada, et al 2005
    }
    
    kurine = kurinec*BW^(-0.25)
    Tm = Tmc*BW^0.75   #transporter maximum
    
    # Free fraction of chemical in tissues
    FreeL = Free/PL  #liver
    FreeF = Free/PF  #fat
    FreeK = Free/PK  #kidney
    FreeSk = Free/PSk #skin
    FreeR = Free/PR  #rest of tissues
    FreeG = Free/PG  #gut
    
    return(list('QC'=QC, 'QCP'=QCP, 'QL'=QL, 'QF'=QF, 'QK'=QK, 
                'Qfil'=Qfil, 'QG'=QG, 'QSk'=QSk, 'QR'=QR,
                'VPlas'=VPlas, 'VL'=VL, 'VF'=VF, 'VK'=VK, 
                'Vfil'=Vfil, 'VG'=VG, 'VSk'=VSk, 'VR'=VR,
                'PL'=PL, 'PF'=PF, 'PK'=PK, 'PSk'=PSk,
                'PG'=PG, 'PR'=PR,
                'Tm'=Tm, 'Kt'=Kt, 'Free'=Free,
                'FreeL'=FreeL, 'FreeF'=FreeF, 'FreeK'=FreeK,
                'FreeSk'=FreeSk, 'FreeR'=FreeR, 'FreeG'=FreeG, 
                'kurine'=kurine,
                "ingestion" = ingestion, "ingestion_time" = ingestion_time,
                "admin_dose" = admin_dose, "admin_time" = admin_time,
                "admin_type" = admin_type, "exp_type" = exp_type
    ))
  })
}

#' 
#' @export
#'  
.create.inits.loccisano <- function(parameters){
  with(as.list(parameters),{
    APlas<-0; AG<-0; AL<-0; AK<-0; AF<-0; Afil<-0; AStore<-0; AUrine<-0; ASk<-0;
    AR<-0; ingestion<-0; 
    return(c('APlas'=APlas, 'AG'=AG, 'AL'=AL, 'AF'=AF, 'AK'=AK, 
             'Afil'=Afil, 'AStore'=AStore, 'AUrine'=AUrine, 'ASk'=ASk, 
             'AR'=AR, 'ingestion'=ingestion))
  })
}

#'  
#' @export
.create.events.loccisano <- function(parameters){
  with(as.list(parameters), {
    if (tolower(admin_type) == "iv"){
      # Calculate number of administrated doses and corresponding administration time for IV
      ldose <- length(admin_dose)
      ltimes <- length(admin_time)
      # If not equal, then stop 
      if (ltimes != ldose){
        stop("The times of administration should be equal in number to the doses")
      }else{
        events <- list(data = rbind(data.frame(var = c("APlas"),  time = admin_time, 
                                               value = admin_dose, method = c("add")) ))
      }
    }else{
      lingest <- length(ingestion)
      lingesttimes <- length(ingestion_time)
      # If not equal, then stop 
      if (lingest != lingesttimes){
        stop("The times of ingestion rate change should be equal to the ingestion time vector")
      }else{
        if(exp_type == "pharmacokinetics"){
          # For pharmacokinetic studies, add the dose directly to the gut compartment
          events <- list(data = data.frame(var = c("AG"),  time = ingestion_time, 
                                           value = ingestion, method = c("add")))
        }else{
          # For continuous exposure studies, set the ingestion rate
          events <- list(data = data.frame(var = c("ingestion"),  time = ingestion_time, 
                                           value = ingestion, method = c("rep")))
        }
      }
    }
    
    return(events)
  })
}

#'  
#' @export
#' 
.custom.func <- function(){
  return()
}

#' 
#' @export
#'  
.ode.func.loccisano <- function(time, inits, params, custom.func){
  with(as.list(c(inits, params)),{
    # Concentrations
    CPlas <- APlas/VPlas # Concentration in plasma
    CG <- AG/VG # Concentration in gut 
    CL <- AL/VL # Concentration in liver
    CF <- AF/VF # Concentration in fat
    CK <- AK/VK # Concentration in kidney
    Cfil <- Afil/Vfil # Concentration in filtrate
    CSk <- ASk/VSk # Concentration in skin
    CR <- AR/VR
    
    # Plasma Compartment
    dAPlas <- QF*CF*FreeF + (QL+QG)*CL*FreeL + QR*CR*FreeR + QSk*CSk*FreeSk + 
      QK*CK*FreeK - QCP*CPlas*Free 
    
    # Gut compartment
    dAG <- QG*(CPlas*Free - CG*FreeG) + ingestion
    
    # Liver compartment
    dAL <- QL*CPlas*Free + QG*CG*FreeG - (QL+QG)*CL*FreeL 
    
    # Fat compartment
    dAF <- QF*(CPlas*Free - CF*FreeF)
    
    # Kidney compartment
    dAK <- QK*(CPlas*Free - CK*FreeK) + (Tm*Cfil)/(Kt+Cfil)
    
    # Filtrate compartment
    dAfil = Qfil*(CPlas*Free - Cfil) - (Tm*Cfil)/(Kt+Cfil)
    
    # Storage compartment
    dAStore <- Qfil*Cfil - kurine*AStore
    
    # Urine
    dAUrine <- kurine*AStore
    
    # Skin compartment
    dASk <- QSk*(CPlas*Free-CSk*FreeSk) #+ input4*DoseOn
    
    # Rest of the body
    dAR <- QR*(CPlas*Free - CR*FreeR)
    
    # PFAS concentration
    dingestion <- 0
    
    Atotal <- APlas+AG+AL+AF+AK+Afil+AStore+AUrine+AR+ASk
    
    
    return(list(c('dAPlas'=dAPlas, 'dAG'=dAG, 'dAL'=dAL, 'dAF'=dAF,
                  'dAK'=dAK, 'dAfil'=dAfil, 'dAStore'=dAStore,
                  'dAUrine'=dAUrine, 'dASk'=dASk, 'dAR'=dAR, 'dingestion'=dingestion),
                'CPlas'=CPlas, 'CG'=CG, 'CL'=CL, 'CF'=CF,
                'CK'=CK, 'Cfil'=Cfil, 'CSk'=CSk, 'CR'=CR,  
                "Cserum" = CPlas, "Cliver" = CL, "Atotal" = Atotal))
  })
}
